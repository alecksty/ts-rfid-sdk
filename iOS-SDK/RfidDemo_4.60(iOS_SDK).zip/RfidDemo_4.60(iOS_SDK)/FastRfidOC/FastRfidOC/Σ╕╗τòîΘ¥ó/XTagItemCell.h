//
//  XTagItemCell.h
//  FastRfidOC
//
//  Created by shitanyu on 2018/10/24.
//  Copyright © 2018 shitanyu. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface XTagItemCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *label_index;
@property (weak, nonatomic) IBOutlet UILabel *label_title;
@property (weak, nonatomic) IBOutlet UILabel *label_count;
@property (weak, nonatomic) IBOutlet UILabel *label_pc;
@property (weak, nonatomic) IBOutlet UILabel *label_crc;
@property (weak, nonatomic) IBOutlet UIImage *image_tomenu;

@end

NS_ASSUME_NONNULL_END
