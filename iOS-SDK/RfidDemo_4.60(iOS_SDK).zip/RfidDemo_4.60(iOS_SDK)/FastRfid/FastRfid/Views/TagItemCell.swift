//
//  TagItemCell.swift
//  FastRfid
//
//  Created by shitanyu on 2018/6/16.
//  Copyright © 2018年 shitanyu. All rights reserved.
//

import UIKit

///
/// 标签单元
///
class TagItemCell: UITableViewCell {

    /// 序号
    @IBOutlet weak var label_index  : UILabel!
    /// 标题（标签epc/tid/user/rfu）
    @IBOutlet weak var label_title  : UILabel!
    /// 通讯协议
    @IBOutlet weak var label_pc     : UILabel!
    /// 校验码
    @IBOutlet weak var label_crc    : UILabel!
    /// 信号
    @IBOutlet weak var label_rssi   : UILabel!
    /// 次数累计
    @IBOutlet weak var label_count  : UILabel!
    /// 图标显示
    @IBOutlet weak var image_tomenu : UIImageView!

    /// 从文件恢复
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    /// 选中效果
    override func setSelected(_ selected:Bool, animated:Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }    
}
