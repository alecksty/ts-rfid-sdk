//
//  BleTableController.swift
//  FastRfid
//
//  Created by shitanyu on 2018/6/14.
//  Copyright © 2018年 shitanyu. All rights reserved.
//

import UIKit
import RfidLib
import CoreBluetooth

/// 修改对象
class BleViewCell :UITableViewCell{
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style:CellStyle.subtitle,reuseIdentifier:reuseIdentifier);
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented");
    }
}

/// 蓝牙列表
class BleTableController: UITableViewController ,BleManagerDelegate{
    /// 调试开关
    private let DEBUG = AppDelegate.DEBUG;
    /// 单元名称
    private let kCellId = "BleDeviceCell";
    /// 本地指针
    private var bleManager : BleManager?;

    ///-------------------------------------------------------------------------
    ///  界面加载
    ///-------------------------------------------------------------------------
    override func viewDidLoad() {
        super.viewDidLoad()

        /// 获取蓝牙管理器
        bleManager =  AppDelegate.portManager?.getBleManager();
        /// 蓝牙响应消息
        bleManager!.delegate = self;
        /// 注册类
        tableView.register(BleViewCell.self, forCellReuseIdentifier: kCellId);
        //  标题
        self.title = NSLocalizedString("BLUETOOTH", comment: "蓝牙");
    }

    //    MARK: - view event -
    override func viewDidDisappear(_ animated: Bool) {
        if(DEBUG){
            print("viewDidDisappear\n");
        }
    }

    //
    override func viewDidAppear(_ animated: Bool) {
        if(DEBUG){
            print("viewDidAppear\n");
        }
        //  获取指针
        bleManager              = AppDelegate.portManager?.getBleManager();
        //  蓝牙响应消息
        bleManager?.delegate    = self

        _ = bleManager!.scan(onoff: true);
    }

    override func viewWillAppear(_ animated: Bool) {
        if(DEBUG){
            print("viewWillAppear\n");
        }
    }

    override func viewWillDisappear(_ animated: Bool) {
        if(DEBUG){
            print("viewWillDisappear\n");
        }

        _ = bleManager!.scan(onoff: false);
    }

    // MARK: - Table view data source

    //
    //  分组
    //
    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    //
    //  行数
    //
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return bleManager!.arrayPeripherals.count
    }

    //
    // 单元格
    //
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        var cell:UITableViewCell? = tableView.dequeueReusableCell(withIdentifier: kCellId, for: indexPath)
        if(cell == nil){
            cell = UITableViewCell(style: UITableViewCell.CellStyle.subtitle, reuseIdentifier: kCellId);
        }

        //  设备
        let dev:CBPeripheral = bleManager!.arrayPeripherals[indexPath.row] as! CBPeripheral;

        //  设备名称
        cell!.textLabel?.text = dev.name;
        //  设备地址
        cell!.detailTextLabel?.text = dev.identifier.uuidString;

        //  设备有效
        if(bleManager?.uartPeripheral != nil){
            //  设备相等
            if(bleManager?.uartPeripheral.isEqual(dev))!{
                cell!.textLabel?.textColor = UIColor.orange
            }else{
                cell!.textLabel?.textColor = UIColor.darkGray
            }
        }else{
            cell!.textLabel?.textColor = UIColor.darkGray
        }

        return cell!;

    }


    // MARK: - Navigation
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if(DEBUG){
            print(String(format: "选中数据:%d\n",indexPath.row));
        }

        if(bleManager != nil){
            let dev:CBPeripheral = bleManager!.arrayPeripherals[indexPath.row] as! CBPeripheral;
            //  连接到设备!
            _ = bleManager!.connect(dev);
        }
    }

    //    MARK: - 蓝牙管理器代理 -
    func onBleEvent(dev: CBPeripheral?, msg: Int, state: Int, text: String?) {

        if(text != nil){
            MsgMake.instance.show(MessageType.MSG_NOTIFY,text!,1.0);
        }

        switch msg {
        //  连接
        case BleManager.BLE_MSG_CONNECT_DEVICE:
            if(state == BleManager.BLE_STATE_START){
                if(dev != nil){
                    MsgMake.instance.show("连接到设备\(String(describing: dev!.name))");
                }
            }else if(state == BleManager.BLE_STATE_DOING){
                MsgMake.instance.show("连接设备中...");
            }else if(state == BleManager.BLE_STATE_FAILED){
                MsgMake.instance.show("连接设备失败！");
            }
            break

        //  断开
        case BleManager.BLE_MSG_DISCONNECT_DEVICE:
            if(state == BleManager.BLE_STATE_START){
                if(dev != nil){
                    MsgMake.instance.show("断开设备\(String(describing: dev!.name))");
                }
            }else if(state == BleManager.BLE_STATE_DOING){
                MsgMake.instance.show("断开设备中...");
            }else if(state == BleManager.BLE_STATE_FAILED){
                MsgMake.instance.show("断开设备失败!");
            }
            break

            //  更新
        case BleManager.BLE_MSG_UPDATE_DEVICE:
            self.tableView.reloadData()
            break

        case BleManager.BLE_MSG_UPDATE_SERVICE:
            self.tableView.reloadData()
            break

        case BleManager.BLE_MSG_UPDATE_CHARACT:
            self.tableView.reloadData()
            break

        case BleManager.BLE_MSG_UPDATE_DESCRIPT:
            self.tableView.reloadData()
            break

        default:
            break
        }
    }

    //
    //  MARK: - 收到数据 -
    //
    func onBleRxData(dev: CBPeripheral, data: [UInt8], error: Error?) {
        AppDelegate.rfidManager!.dataIn(data);
    }
}
