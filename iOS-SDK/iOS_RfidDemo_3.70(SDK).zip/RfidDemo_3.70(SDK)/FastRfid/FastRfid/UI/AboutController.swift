//
//  AboutController.swift
//  FastRfid
//
//  Created by shitanyu on 2018/6/18.
//  Copyright © 2018年 shitanyu. All rights reserved.
//

import UIKit

class AboutController: UIViewController {

    @IBOutlet weak var labelVersion: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.title = NSLocalizedString("ABOUT", comment: "关于");
    }

    //
    override func viewWillAppear(_ animated: Bool) {

        let infoDictionary = Bundle.main.infoDictionary
        if let infoDictionary = infoDictionary {
            let appVersion = infoDictionary["CFBundleShortVersionString"]
            let appBuild = infoDictionary["CFBundleVersion"];
            NSLog("version\(String(describing: appVersion)),build\(String(describing: appBuild))");

            let strVersion = appVersion as! String;
            let s : String = "版本 : " + strVersion;
            labelVersion.text = s;
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}
