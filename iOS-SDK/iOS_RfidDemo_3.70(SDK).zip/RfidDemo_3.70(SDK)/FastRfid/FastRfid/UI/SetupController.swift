//
//  SetupController.swift
//  FastRfid
//
//  Created by shitanyu on 2018/6/12.
//  Copyright © 2018年 shitanyu. All rights reserved.
//
import UIKit
import RfidLib
import Foundation

//==============================================================================
//  设置界面
//==============================================================================
class SetupListUi: UITableViewController,XSetupDelegate {

    //  字符串数组
    public var _dataItems : [String]?;

    //  单元格样式
    public var _cellStyle : UITableViewCell.CellStyle?;

    //  接口
    private  let XITEM_USART    = 1000;
    private  let XITEM_BLE      = 1001;
    private  let XITEM_WIFI     = 1002;
    private  let XITEM_UART     = 1003;
    private  let XITEM_USB      = 1004;
    //  指令集
    private  let XITEM_INSTRUCTION      = 1100;
    //  设备
    private  let XITEM_RX_POWER = 2003;
    private  let XITEM_AREA     = 2004;
    private  let XITEM_FREQ     = 2005;
    private  let XITEM_SKIP     = 2006;
    private  let XITEM_TX_POWER = 2007;
    //  操作
    private  let XITEM_SHAKE    = 3008;
    private  let XITEM_SOUND    = 3009;
    private  let XITEM_TIMES    = 3010;

    //  其他
    private  let XITEM_DEBUG    = 4000;
    private  let XITEM_ABOUT    = 4001;

    //  设置管理器
    private var setupManager = XSetupManager();

    //    MARK: - 函数接口 -
    /// 状态栏风格
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }

    ///-------------------------------------------------------------------------
    /// 加载数据
    ///-------------------------------------------------------------------------
    override func viewDidLoad() {

        // Uncomment the following line to preserve selection between presentations
        self.clearsSelectionOnViewWillAppear = false

        //  返回键
//        let returnItem = UIBarButtonItem(title: NSLocalizedString("RETURN", comment: "返回"),
//                                         style: .plain,
//                                         target: self,
//                                         action: #selector(action_back));
//
//        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
//        self.navigationItem.leftBarButtonItem = returnItem

        //  加载列表
        initList();
    }

    //  开始
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isToolbarHidden = true;
        self.navigationController?.isNavigationBarHidden = false;
        self.navigationController?.isEditing = false;
        self.navigationController?.becomeFirstResponder();
    }

    ///
    /// 响应
    ///
    /// - Parameter animated: 动画
    override func viewDidAppear(_ animated: Bool) {
//        self.navigationController?.isToolbarHidden = true;
//        self.navigationController?.isNavigationBarHidden = false;
//        self.navigationController?.isEditing = false;
//        self.navigationController?.becomeFirstResponder();
    }

    ///-------------------------------------------------------------------------
    /// 列表初始化
    ///-------------------------------------------------------------------------
    func initList(){
        //  信号强度
        let arraySmart = [
            NSLocalizedString("HIGH", comment: "高"),
            NSLocalizedString("MID" , comment: "中"),
            NSLocalizedString("LOW" , comment: "低")
        ];

        //  区域
        let arrayArea  = [
            NSLocalizedString("AREA CN800", comment:"中国800Mhz"),
            NSLocalizedString("AREA CN900", comment:"中国900Mhz"),
            NSLocalizedString("AREA USA", comment:"美国"),
            NSLocalizedString("AREA EROUP", comment:"欧洲"),
            NSLocalizedString("AREA KOREA", comment:"韩国")
        ];

        //  指令集
        let arrayInstruct = [
            NSLocalizedString("INSTRUCT R2000", comment:"R2000 (H3/H8/R1/R4/R8/D1)"),
            NSLocalizedString("INSTRUCT M100", comment:"QM100 (H1/H2/T1)"),
            NSLocalizedString("INSTRUCT PR9200", comment:"PR9200 (H9)"),
            NSLocalizedString("INSTRUCT SLR5300", comment:"SLR5300 (H5/H6/H7)"),
        ];

        //  输出功率
        let arrayTxPower  = ["26 dB", "20 dB", "18.5 dB", "17 dB", "15.5 dB", "14 dB", "12.5 dB",];
        //  每秒次数
        let arrayTimesSec = ["100", "50", "20", "10"];
        //  蓝牙管理器
        let bleMan      = AppDelegate.portManager?.getBleManager();
        //  设备
        let device      = bleMan?.uartPeripheral;
        //  未连接
        let strNone     = NSLocalizedString("NONE", comment:"未连接");
        //  设备名
        var devName     = strNone;
        //  有设备名
        if (device != nil) {
            devName = (device?.name)!
        }

        //  界面加载
        let storyboard  = UIStoryboard(name: "Main", bundle: nil)
        //  蓝牙界面
        let intentBle   : BleTableController    = storyboard.instantiateViewController(withIdentifier: "BleTableController") as! BleTableController;
        //  关于界面
        let intentAbout : AboutController       = storyboard.instantiateViewController(withIdentifier: "AboutController") as! AboutController;

        //  分配列表
        setupManager.clear()

        //  添加设备组
        setupManager.add(XSetupItem(NSLocalizedString("SETUP_PORT", comment:"接口")));
        setupManager.add(XSetupItem(XITEM_BLE,title: NSLocalizedString("PORT_BLE", comment:"蓝牙"),text:devName,intent:intentBle));
        setupManager.add(XSetupItem(XITEM_WIFI, NSLocalizedString("PORT_TCPIP", comment:"网络"), strNone));
        setupManager.add(XSetupItem(XITEM_UART, NSLocalizedString("PORT_UART", comment:"串口"), strNone));
        setupManager.add(XSetupItem(XITEM_USB, NSLocalizedString("PORT_USB", comment:"USB"), strNone));

        //  添加设备属性
        setupManager.add(XSetupItem(NSLocalizedString("SETUP_INSTRUCTION", comment:"指令集")));
        setupManager.add(XSetupItem(XITEM_INSTRUCTION,title: NSLocalizedString("DEVICE_INSTRUCTION", comment:"指令"),pos:(AppDelegate.rfidManager?.getReader()?.getType().rawValue)!,array: arrayInstruct));

        //  添加设备属性
        setupManager.add(XSetupItem(NSLocalizedString("SETUP_DEVICE", comment:"设备")));
        setupManager.add(XSetupItem(XITEM_RX_POWER,title: NSLocalizedString("DEVICE_RX_POWER", comment:"灵敏度"),pos: 0,array: arraySmart));
        setupManager.add(XSetupItem(XITEM_AREA,title: NSLocalizedString("DEVICE_AREA", comment:"区域"),pos: 0,array: arrayArea));
//        setupManager.add(XSetupItem(XITEM_FREQ,title: "频率",pos: 0,array: arrayFreq));
        setupManager.add(XSetupItem(XITEM_SKIP,title: NSLocalizedString("DEVICE_AUTO_SKIP", comment:"跳频"),onoff: true));
        setupManager.add(XSetupItem(XITEM_TX_POWER,title: NSLocalizedString("DEVICE_TX_POWER", comment:"功率"),pos: 0,array: arrayTxPower));

        setupManager.add(XSetupItem(NSLocalizedString("SETUP_OPRATE", comment:"操作")));
        setupManager.add(XSetupItem(XITEM_SOUND,title: NSLocalizedString("OPRATE_SOUND", comment:"声音"),onoff: false));
        setupManager.add(XSetupItem(XITEM_SHAKE,title: NSLocalizedString("OPRATE_SHAKE", comment:"震动"),onoff: false));
        setupManager.add(XSetupItem(XITEM_SHAKE,title: NSLocalizedString("OPRATE_TIMES", comment:"每秒次数"),pos: 1,array: arrayTimesSec));

        setupManager.add(XSetupItem(NSLocalizedString("SETUP_OTHER", comment:"其他")));
        //setupManager.add(XSetupItem(XITEM_RESET, NSLocalizedString("OTHER_RESET", comment:"复位")));
        setupManager.add(XSetupItem(XITEM_ABOUT,title:NSLocalizedString("OTHER_ABOUT", comment:"关于"),intent:intentAbout));

        // 设置管理器关联
        setupManager.setTableView(tableView,self,self);
    }

    /// 返回
    @IBAction func action_back(){
        self.dismiss(animated: true, completion: nil)
    }

    /**
     * 设置响应
     *
     * - parameter msg   : 消息
     * - parameter item  : 设置项目
     * - parameter id    : 项目标号
     * - parameter on    : 逻辑值
     * - parameter pos   : 选择值
     * - parameter text  : 文本值
     * - parameter param : 参数
     */
    func OnSetupEvent(msg:Int,item:XSetupItem,id:Int,on:Bool,pos:Int,text:String?,param:Any?) {

        if(on){
            NSLog("msg:%d,item:%@,id:%d,on:YES,pos:%d\n",msg,item,id,pos)
        }else{
            NSLog("msg:%d,item:%@,id:%d,on:NO,pos:%d\n",msg,item,id,pos)
        }

        switch (id) {
        //===============
        //  串口
        //===============
        case XITEM_USART:
            break;

        //===============
        //  蓝牙
        //===============
        case XITEM_BLE:
            break;

        //===============
        //  网络
        //===============
        case XITEM_WIFI:
            break;

        //===============
        //  指令
        //===============
        case XITEM_INSTRUCTION:
            NSLog("指令集:%d",pos);
            //  切换指令集
            AppDelegate.rfidManager!.setType(ReaderType(rawValue: pos)!);
            AppDelegate.rfidManager!.setupUpdate(true);
            break;

        //===============
        //  灵敏度
        //===============
        case XITEM_RX_POWER:
            NSLog("灵敏度 : %d", pos);
            break;

        //===============
        //  区域
        //===============
        case XITEM_AREA:
            NSLog("区域 : %d", pos);
            //rfid_putArray(bytes:RfidMake.cmd.set_region(region: UInt8(1 + pos)));            
            break;

        //===============
        //  频率
        //===============
        case XITEM_FREQ:
            NSLog("频率 : %d", pos);
            //rfid_putArray(bytes:RfidMake.cmd.set_tx_power(power: UInt16(pos & 0xffff)));
            break;

        //===============
        //  跳频
        //===============
        case XITEM_SKIP:
            NSLog("跳频 : %d", on);
            //rfid_putArray(bytes: RfidMake.cmd.set_auto(auto: on));
            break;

        //===============
        //  功率
        //===============
        case XITEM_TX_POWER:
            NSLog("功率 : :%d",pos);
            let cmd = AppDelegate.rfidManager?.getReader()?.baseCmd;
            AppDelegate.portWrite(cmd?.rfid_set_tx_power(UInt8(pos)));
            AppDelegate.rfidManager!.setupUpdate(true);
            break;

        //===============
        //  声音
        //===============
        case XITEM_SOUND:
            break;

        //===============
        //  震动
        //===============
        case XITEM_SHAKE:
            break;

        //===============
        //  次数
        //===============
        case XITEM_TIMES:
            break;

        //===============
        //  调试
        //===============
        case XITEM_DEBUG:
            break;

        default:
            break;
        }
    }
}
