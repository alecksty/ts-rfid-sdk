//
//  ContentUI.swift
//  FastRfid
//
//  Created by shitanyu on 2018/12/1.
//  Copyright © 2018 shitanyu. All rights reserved.
//

import RfidLib
import UIKit

class ContentController : UIViewController ,RfidEvent{

    // MARK: - 调试
    private let DEBUG = AppDelegate.DEBUG;
    private let TAG   = "ContentController";

    // MARK: - 控件
    @IBOutlet weak var label_EPC: UILabel!;
    @IBOutlet weak var label_TID: UILabel!;
    @IBOutlet weak var label_RFU: UILabel!;
    @IBOutlet weak var label_USR: UILabel!;

    // MARK: - 菜单

    /// 菜单序号
    private static let ID_MSG_MENU     = 1000;
    private static let ID_MSG_EDIT_EPC = 1001;
    private static let ID_MSG_EDIT_TID = 1002;
    private static let ID_MSG_EDIT_RFU = 1003;
    private static let ID_MSG_EDIT_USR = 1004;

    /// 之前状态
    private static var oldRun = false;

    /// 当前标签
    private static var tagItem:TagItem? = nil;

    private let MAX_COUNT = 10;

    private var errorCount = 0;

    // MARK: - 接口

    ///-------------------------------------------------------------------------
    /// 输入对话框
    ///
    /// - Parameters:
    ///   - title   : 标题
    ///   - message : 消息
    ///   - value   : 数据
    ///-------------------------------------------------------------------------
    func dialogInput(_ title:String,_ message:String,_ value:String) {
        //  初始化
        var inputText = UITextField();
        //  对话框
        let dlg = UIAlertController.init(title: title, message: message, preferredStyle: .alert);
        //  确定
        let actionOk = UIAlertAction.init(title: NSLocalizedString("OK", comment: "确定"), style:.default){ (action:UIAlertAction)->() in

            print("你输入的是：\(String(describing: inputText.text))");

            let text = inputText.text;

            //  这里不允许执行时间长的代码!
            DispatchQueue.main.async(execute: {
                if(ContentController.tagItem != nil){
                    if(text != nil){
                        _ = self.tagChangeEPC(ContentController.tagItem!,text!);
                    }
                }
            });
        }
        //  取消
        let actionCancel = UIAlertAction.init(title: NSLocalizedString("CANCEL", comment: "取消"),
                                              style:.cancel){ (action:UIAlertAction)->() in
            print("取消输入");
        }

        //  添加按钮
        dlg.addAction(actionOk);
        dlg.addAction(actionCancel);

        //  添加输入框
        dlg.addTextField { (textField:UITextField) in
            //  设置传入的textField为初始化UITextField
            inputText = textField;
            inputText.text = value;
            inputText.placeholder = "...";
        }

        //  设置到当前视图
        self.present(dlg, animated: true, completion: nil);
    }

    /// 读取标签
    ///
    /// - Parameter sender: 发送者
    @IBAction func click_tag_read(_ sender: Any) {

    }


    /// 输入EPC
    ///
    /// - Parameter sender: 发送者
    @IBAction func click_tag_edit(_ sender: Any) {
        let s : String = ContentController.tagItem!.getTextEpc();
        //
        dialogInput("输入","输入EPC",s);
    }

    @IBAction func click_tag_lock(_ sender: Any) {

    }

    @IBAction func click_kill(_ sender: Any) {
    }

    // MARK: - 普通接口

    override func viewDidLoad() {
        super.viewDidLoad();
    }

    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = false;
        self.navigationController?.isToolbarHidden = true;
        self.navigationController?.becomeFirstResponder();

        if(ContentController.tagItem != nil){
            //  全部读取
            _ = tagReadAll(ContentController.tagItem!);

            viewShowData(tag: ContentController.tagItem);
        }
        
    }

    ///-------------------------------------------------------------------------
    /// 取得焦点
    ///
    /// - Parameter animated: 动画
    ///-------------------------------------------------------------------------
    override func viewDidAppear(_ animated: Bool) {
        //  记录状态
        ContentController.oldRun = AppDelegate.rfidManager!.isRunning;
        //  取消运行
        AppDelegate.rfidManager!.isRunning = false;
        //  读写器
        let reader = AppDelegate.rfidManager!.getReader();
        //  应答
        reader!.baseAck!.setEvent(self);
        //  stop
        AppDelegate.portWrite(reader!.baseCmd!.rfid_stop()!);

        if(ContentController.tagItem != nil){
            //  全部读取
            _ = tagReadAll(ContentController.tagItem!);

            viewShowData(tag: ContentController.tagItem);
        }
    }

    ///-------------------------------------------------------------------------
    /// 离开焦点
    ///
    /// - Parameter animated: 动画
    ///-------------------------------------------------------------------------
    func viewShowData(tag:TagItem?){
        if(tag != nil){
            label_EPC.text = tag!.getTextEpc();
            label_RFU.text = tag!.getTextRfu();
            label_TID.text = tag!.getTextTid();
            label_USR.text = tag!.getTextUsr();
        }
    }

    ///-------------------------------------------------------------------------
    /// 离开焦点
    ///
    /// - Parameter animated: 动画
    ///-------------------------------------------------------------------------
    override func viewDidDisappear(_ animated: Bool) {
        AppDelegate.rfidManager!.isRunning = ContentController.oldRun;
    }

    // MARK: - 自定义
    /**
     * 当前目标
     *
     * @param tag ： 标签
     */
    public static func setTagItem(_ tag:TagItem) {
        tagItem = tag;
    }

    @IBAction func click_return(_ sender: Any) {
        self.dismiss(animated: true, completion: nil);
        //self.navigationController!.popViewController(animated: true);
        //self.navigationController!.dismiss(animated: true, completion: nil);

        self.presentingViewController!.dismiss(animated: true, completion: nil)

        //self.performSegue(withIdentifier: "segue_return", sender: nil);
    }

    /// 返回
    @objc public func action_return(){
        //self.dismiss(animated: true, completion: nil);
        //self.navigationController!.popViewController(animated: true);
        //self.navigationController!.dismiss(animated: true, completion: nil);

        //self.presentingViewController!.dismiss(animated: true, completion: nil)
    }

    @IBAction func unwindToMain(_ unwindSegue: UIStoryboardSegue) {
        //let sourceViewController = unwindSegue.source
        // Use data from the view controller which initiated the unwind segue
    }

    ///-------------------------------------------------------------------------
    /// 读取全部
    ///
    /// - Parameter tag : 标签
    /// - Returns       : 成功与否
    ///-------------------------------------------------------------------------
    private func tagReadAll(_ tag:TagItem)->Bool {
        //  读写器
        let reader:BaseReader = AppDelegate.rfidManager!.getReader()!;
        //  命令
        let cmd = reader.baseCmd!;
        //  清空
        AppDelegate.rfidManager!.cleanCmd();
        //  停止
        AppDelegate.portWrite(cmd.rfid_stop());
        //  选择
        AppDelegate.portWrite(cmd.rfid_set_select(UInt8(BaseCmd.RFID_BANK_EPC), 0, tag.epc!));
        //  读选择
        AppDelegate.portWrite(cmd.rfid_get_select());

        errorCount = 0;
        //  读取数据 (96 bits - 12 Bytes)
        //  H3 芯片支持到 480 bits
        AppDelegate.portWrite(cmd.rfid_read(0, UInt8(BaseCmd.RFID_BANK_EPC), 0, UInt16(tag.epc!.count)));
        //  读取数据 (64 bits - 8 Bytes)
        AppDelegate.portWrite(cmd.rfid_read(0, UInt8(BaseCmd.RFID_BANK_TID), 0, 8));
        //  读取数据 (64 bits - 8 Bytes)
        AppDelegate.portWrite(cmd.rfid_read(0, UInt8(BaseCmd.RFID_BANK_RFU), 0, 8));
        //  读取数据 (256 bits - 32 Bytes)
        AppDelegate.portWrite(cmd.rfid_read(0, UInt8(BaseCmd.RFID_BANK_USR), 0, 32));
        //  提示状态

        _ = MsgMake(MessageType.MSG_WARNING, NSLocalizedString("WAITING", comment: "处理中..."), 3.0);

        return true;
    }

    ///-------------------------------------------------------------------------
    /// 改变EPC
    ///
    /// - Parameters:
    ///   - tag     : 标签
    ///   - newEpc  : 名称
    /// - Returns   : 成功
    ///-------------------------------------------------------------------------
    private func tagChangeEPC(_ tag:TagItem,_  newEpc:String)->Bool {

        var array:[UInt8] = [UInt8]();
        //  读写器
        let reader = AppDelegate.rfidManager!.getReader();
        let cmd = reader?.baseCmd;

        if(newEpc.count == 0){
            return false;
        }

        errorCount = 0;

        //  清空
        AppDelegate.rfidManager!.cleanCmd();
        //  初始化
        AppDelegate.portWrite(cmd!.rfid_init());
        //  停止
        AppDelegate.portWrite(cmd!.rfid_stop());
        //  选择
        AppDelegate.portWrite(cmd!.rfid_set_select(UInt8(BaseCmd.RFID_BANK_EPC), 0, tag.epc!));

        if (DEBUG) {
            NSLog("选中标签 : " + tag.getTextEpc());
        }

        //  读取选择
        AppDelegate.portWrite(cmd!.rfid_get_select());
        if (DEBUG) {
            NSLog("获取选中!");
        }

        //  编码转换
        let data = newEpc.data(using: String.Encoding.utf8);

        //  转换失败
        if(data == nil){
            NSLog("data is nil!");
            return false;
        }

        //  数据
        array = [UInt8](data!);

        errorCount = 0;

        _ = MsgMake(MessageType.MSG_WARNING, NSLocalizedString("WAITING", comment: "处理中..."), 1.0);

        for _ in 0..<MAX_COUNT {
            //  选择
            AppDelegate.portWrite(cmd!.rfid_set_select(UInt8(BaseCmd.RFID_BANK_EPC), 0, tag.epc!));
            //  写标签
            AppDelegate.portWrite(cmd!.rfid_write(0, UInt8(BaseCmd.RFID_BANK_EPC), 0, array));
        }

        if (DEBUG) {
            NSLog("写入标签!" + PortBase.dumpArray(array));
        }

        //  读取数据
        AppDelegate.portWrite(cmd!.rfid_read(0, UInt8(BaseCmd.RFID_BANK_EPC), 0, UInt16(tag.epc!.count)));
        //  提示状态
        _ = MsgMake(MessageType.MSG_WARNING,NSLocalizedString("DONE", comment: "处理完成!"), 1.0);

        NSLog("写EPC完毕！-" + PortBase.dumpArray(array));

        return true;
    }

    // MARK: - 消息接口

    ///-------------------------------------------------------------------------
    /// 消息接口
    ///
    /// - Parameters:
    ///   - type    : 类型
    ///   - cmd     : 命令
    ///   - param   : 参数
    ///   - obj     : 对象
    ///
    ///-------------------------------------------------------------------------
    func OnRfidResponse(_ type: Int, _ cmd: Int, _ param: [UInt8]?, _ obj: Any?) {

        if(DEBUG){
            if(obj is String){
                print(String(format: "OnRfidResponse(type:%d,cmd:%02x,param:%@,obj:%@)\n", type,cmd,PortBase.dumpArray(param),obj as! String));
            }else{
                print(String(format: "OnRfidResponse(type:%d,cmd:%02x,param:%@)\n", type,cmd,PortBase.dumpArray(param)));
            }
        }

        if (type == BaseAck.RESPONSE_TYPE_RESPONSE) {
            let sepc = ContentController.tagItem!.getTextEpc();
            //====================
            //  选中
            //====================
            if (cmd ==  RfidM100Cmd.CMD_M100_SET_SELECT) {
                if (param != nil) {
                    if (param!.count > 0) {
                        //  成功
                        if (param![0] == 0) {
                            if(errorCount >= 0){
                                _ = MsgMake(MessageType.MSG_NOTIFY,NSLocalizedString("SELECT", comment: "选中标签") + " : " + sepc, 1.0);
                                errorCount = 0;
                            }
                        }
                    }
                }

            //====================
            //  写入
            //====================
            } else if (cmd == RfidM100Cmd.CMD_M100_WRITE) {
                if (param != nil) {
                    if (param!.count > 0) {
                        _ = MsgMake( MessageType.MSG_SUCCESS,NSLocalizedString("WRITE", comment: "写入") + " : " + sepc + NSLocalizedString("SUCCESS", comment: "成功"), 2.0);
                        errorCount = -1;
                    }
                }

            //====================
            //  错误
            //====================
            } else if (cmd == RfidM100Cmd.CMD_M100_ERROR) {
                if (param != nil) {
                    if (param!.count > 0) {
                        if (param![0] == 0x10) {
                            if(errorCount >= 0){
                                errorCount += 1;
                            }
                            if(errorCount >= MAX_COUNT){
                                _ = MsgMake( MessageType.MSG_ERROR,NSLocalizedString("WRITE", comment: "写入") + " : " + sepc + NSLocalizedString("FAILED", comment: "失败") + "\(errorCount)", 1.0);
                            }
                            if(DEBUG) {
                                print("错误累计:%d\n", errorCount);
                            }
                        }
                    }
                }
            }else{
                if(DEBUG){
                    print(String(format:"CMD : %02x\n",cmd));
                }
            }
        }
    }
}
