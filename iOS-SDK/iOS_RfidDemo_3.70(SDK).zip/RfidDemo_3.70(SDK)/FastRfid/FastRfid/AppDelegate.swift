//
//  AppDelegate.swift
//  FastRfid
//
//  Created by shitanyu on 2018/6/10.
//  Copyright © 2018年 shitanyu. All rights reserved.
//

import UIKit
import CoreData
import RfidLib

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    ///  调试
    public static let DEBUG = false

    /// 接口管理器
    public static var portManager : PortManager? = nil;
    /// RFID管理器
    public static var rfidManager : RfidManager? = nil;

    //  窗口
    var window: UIWindow?

    // MARK: - 启动完成
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.

        //  接口管理器
        AppDelegate.portManager = PortManager(PortType.PORT_TYPE_BLE);
        //  读写器管理器
        //AppDelegate.rfidManager = RfidManager(ReaderType.READER_TYPE_M100);
        AppDelegate.rfidManager = RfidManager(ReaderType.READER_TYPE_R2000);
        //  设置接口
        AppDelegate.rfidManager!.setPort(AppDelegate.portManager!.getPort());

#if false
        let text = "中华人民共和国";
        let d = text.data(using: String.Encoding.utf8);
        let real:[UInt8] = [UInt8](d!);
        let r:[UInt8] = [0xcc,0xbd,0xcb,0xf7,0xd6,0xc7,0xc4,0xdc,0xbf,0xc6,0xbc,0xbc,0xd3,0xd0,0xcf,0xde,0xb9,0xab,0xcb,0xbe,0xa3,0xac,0xb6,0xc0,0xb9,0xc2,0xc7,0xf3,0xb0,0xdc,];
        let s = String(bytes: real, encoding: String.Encoding.utf8);
        //let s = String(bytes: r, encoding: String.Encoding.utf8);
        print("===>>>" + PortBase.dumpArray(real));
        print("===>>>" + s!);
        print("===\n");
#endif

        return true
    }

    func applicationWillResignActive(_ application: UIApplication) {
        // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
        // Use this method to pause ongoing tasks, disable timers, and invalidate graphics rendering callbacks. Games should use this method to pause the game.
        print("applicationWillResignActive()\n");
    }

    // MARK: - 进入后台
    func applicationDidEnterBackground(_ application: UIApplication) {
        // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
        // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
        print("applicationDidEnterBackground()\n");
    }

    func applicationWillEnterForeground(_ application: UIApplication) {
        // Called as part of the transition from the background to the active state; here you can undo many of the changes made on entering the background.
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
        // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    }

    func applicationWillTerminate(_ application: UIApplication) {
        // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
        // Saves changes in the application's managed object context before the application terminates.
        self.saveContext()
    }

    // MARK: - 核心数据堆栈
    @objc lazy var persistentContainer: NSPersistentContainer = {
        /*
         The persistent container for the application. This implementation
         creates and returns a container, having loaded the store for the
         application to it. This property is optional since there are legitimate
         error conditions that could cause the creation of the store to fail.
        */
        let container = NSPersistentContainer(name: "FastRfid")
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                 
                /*
                 Typical reasons for an error here include:
                 * The parent directory does not exist, cannot be created, or disallows writing.
                 * The persistent store is not accessible, due to permissions or data protection when the device is locked.
                 * The device is out of space.
                 * The store could not be migrated to the current model version.
                 Check the error message to determine what the actual problem was.
                 */
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()

    // MARK: - 数据支持
    @objc func saveContext () {
        let context = persistentContainer.viewContext
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                // Replace this implementation with code to handle the error appropriately.
                // fatalError() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }

    /**
     * 发送数据
     *
     * @param array : 数据
     */
    public static func portWrite(_ array:[UInt8]?) {

        if (array == nil) {
            if (AppDelegate.DEBUG) {
                NSLog("array is nil\n");
            }
            return;
        }

        if (array!.count == 0) {
            if (AppDelegate.DEBUG) {
                NSLog("array.count == 0\n");
            }
            return;
        }

        AppDelegate.rfidManager!.putCmd(array!);
    }
}

