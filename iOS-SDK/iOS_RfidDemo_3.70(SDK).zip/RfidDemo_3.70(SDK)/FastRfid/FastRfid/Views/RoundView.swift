//
//  RoundView.swift
//  FastRfid
//
//  Created by shitanyu on 2018/12/3.
//  Copyright © 2018 shitanyu. All rights reserved.
//

import UIKit

class RoundView: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
//    override init(frame: CGRect) {
//        super.init(frame: frame);
//    }

    override func draw(_ rect: CGRect) {
        //let p = UIBezierPath(ovalInRect: CGRectMake(0, 0, 100, 100))
        super.draw(rect);
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()

        //  定义渐变的颜色（3种彩虹色）
        //
        //
        #if false
        let gradientColors = [UIColor.gray.cgColor,
                              UIColor.yellow.cgColor,
                              UIColor.yellow.cgColor]

        //  定义每种颜色所在的位置
        let gradientLocations:[NSNumber] = [0.0, 0.5, 1.0]

        if(self.layer != nil){
            //  创建CAGradientLayer对象并设置参数
            let gradientLayer               = CAGradientLayer(layer:self.layer)

            gradientLayer.colors            = gradientColors
            gradientLayer.locations         = gradientLocations

            //  设置渲染的起始结束位置（横向渐变）
            gradientLayer.startPoint        = CGPoint(x: 0, y: 1)
            gradientLayer.endPoint          = CGPoint(x: 0, y: 0)
            gradientLayer.borderColor       = UIColor.gray.cgColor;
            gradientLayer.borderWidth       = 2;
            gradientLayer.cornerRadius      = 10

            //  设置其CAGradientLayer对象的frame，并插入view的layer
            gradientLayer.frame             = CGRect(origin: CGPoint(x:0,y:0), size: self.bounds.size)
            gradientLayer.frame.offsetBy(dx: gradientLayer.frame.minX, dy: gradientLayer.frame.minY)

            self.layer.cornerRadius = 10;

            if(self.layer.sublayers != nil){
                //  超过一个，先要去掉前面的。
                if(self.layer.sublayers!.count > 1){
                    self.layer.sublayers!.remove(at: 0);
                }
                //   插入
                self.layer.insertSublayer(gradientLayer,at:0);
            }
        }
        #else
        self.layer.cornerRadius = 10;
        self.layer.borderColor = UIColor.gray.cgColor;
        self.layer.borderWidth = 2;
        #endif
    }

}
