//
//  MainController.m
//  FastRfidOC
//
//  Created by shitanyu on 2018/10/24.
//  Copyright © 2018 shitanyu. All rights reserved.
//

#import "XMainController.h"
#import "XTagItemCell.h"
#import "AppDelegate.h"

@interface XMainController ()

@end

@implementation XMainController

@synthesize button_start;
@synthesize button_setup;
@synthesize button_export;
@synthesize label_rssi;
@synthesize label_count;

NSString * kCellNib    = @"XTagItemCell";
NSString * kCellId     = @"TagItemId";

#pragma mark - 通用

- (void)viewDidLoad
{
    [super viewDidLoad];
    //  消息接口
    self.table_tags.delegate       = self;
    //  数据源
    self.table_tags.dataSource     = self;
    //  注册单元格
    UINib * nib = [UINib nibWithNibName:kCellNib bundle:[NSBundle mainBundle]];
    //  列表
    [self.table_tags registerNib:nib forCellReuseIdentifier:kCellId];
    //  启动线程
    [self performSelectorInBackground:@selector(threadRun:) withObject:@"参数"];
}

-(void)viewDidAppear:(BOOL)animated
{
    /// 消息接口
    AppDelegate.portManager.event = self;
    /// 消息接口
    AppDelegate.rfidManager.event = self;

    //[AppDelegate.portManager.getBleManager delegate];

    //  检查连接
    if(![[AppDelegate.portManager getPort] isConnected]){
        [[MsgMake getInstance] show:MessageTypeMSG_NOTIFY :@"RFID读写设备没有连接,请先连接设备!" :3.0];
    }

    [self updateStartStop];
}

///-------------------------------------------------------------------------
/// 开始/停止
///-------------------------------------------------------------------------
-(IBAction) doStartStop:(id)sender
{
    UIAlertAction * okAction;
    //  提示
    UIAlertController * alert = [UIAlertController alertControllerWithTitle:@"提示"
                                                                     message:@"未连接RFID读写设备,请先连接\n请在【设置】里的接口选项选择附近设备!"
                                                              preferredStyle:UIAlertControllerStyleAlert];

    //okAction = UIAlertAction(title: "确定", style: .destructive, handler: nil)
    okAction = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDestructive handler:nil];
    [alert addAction:okAction];

    //  设备没有准备好
    if(![AppDelegate.portManager getPort].isConnected){
        //self.present(alert, animated: true, completion: nil);
        [self presentViewController:alert animated:YES completion:nil];
    }else{
        //  反向数据
        AppDelegate.rfidManager.isRunning = !AppDelegate.rfidManager.isRunning;
    }

    //  显示对应
    [self updateStartStop];
}

///-------------------------------------------------------------------------
/// 显示状态
///-------------------------------------------------------------------------
-(void) updateStartStop{
    //  显示对应
    if(AppDelegate.rfidManager.isRunning){
        [button_start setTitle:@"停止" forState:UIControlStateNormal];
    }else{
        [button_start setTitle:@"开始" forState:UIControlStateNormal];
    }
}

#pragma mark - 必须实现的接口
/**
 RFID消息响应

 @param type 类型
 @param cmd 命令
 @param para 参数
 @param obj 对象
 */
-(void)OnRfidResponse:(NSInteger)type :(NSInteger)cmd :(NSArray<NSNumber *> *)para :(id)obj{

    NSLog(@"OnRfidResponse(type:%ld,cmd:%02lx)",(long)type,(long)cmd);

    //=======================
    //  错误消息
    //=======================
    if (type < 0) {
        if(obj != nil){
            if ([obj isKindOfClass:[NSString class]]) {
                NSString * s = (NSString *)obj;
                NSLog(@"%02lx - %@", (long)cmd,s);
            }
        }
        return;
    }

    if(cmd == BaseCmd.RFID_CMD_INVENTORY){
            //==================
            //  收到标签
            //==================
            if (DEBUG) {
                NSLog(@"RFID_CMD_INVENTORY\n");
            }

            if ([obj isKindOfClass:[TagItem class]]) {
                TagItem * tag = (TagItem *)obj;
                //  刷新
                [_table_tags reloadData];
                //  信号强度
                int8_t rssi_n = 0;

                if(tag.rssi > 127){
                    rssi_n = 0 - (256 - tag.rssi);
                }else{
                    rssi_n = tag.rssi;
                }
                label_rssi.text = [NSString stringWithFormat:@"%d",rssi_n];
                //  获取计数
                if(AppDelegate.rfidManager != nil){
                    label_count.text = [NSString stringWithFormat:@"%lu",(unsigned long)AppDelegate.rfidManager.listTag.count ];
                }
            }
    }
    else{
            if (DEBUG) {
                NSLog(@"cmd:%02lx\n",(long)cmd);
            }
    }
}

-(void)onConnect:(id)device :(id)error{

}

-(void)onDisconnect:(id)device :(id)error{
    
}

/**
 接收数据

 @param data 数据
 @param error 错误
 */
-(void)onReceive:(NSArray<NSNumber *> *)data :(id)error{
    if(AppDelegate.rfidManager != nil){
        [AppDelegate.rfidManager dataIn:data];
    }
    NSLog(@"data in\n");
}

/**
线程执行
 @param param : 参数
 */
-(void)threadRun:(NSString *)param{

    while(YES){
        /// 端口
        PortBase * port     = [AppDelegate.portManager getPort];
        /// 读写器
        BaseReader * reader = [AppDelegate.rfidManager getReader];
        //  已经开始
        if(AppDelegate.rfidManager.isRunning){
            // 写数据
            [port sendData:[reader.baseCmd rfid_inventory:10]];

            NSLog(@"send\n");
        }
        usleep(1000 * 150);
    }
    // 回到主线程
    // [self  performSelectorOnMainThread:@selector(update) withObject:nil waitUntilDone:YES];
}

#pragma mark - 表格

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    //  标签数量
    if(AppDelegate.rfidManager != nil){
        if(AppDelegate.rfidManager.listTag  != nil){
            return [AppDelegate.rfidManager.listTag count];
        }
    }
    return 0;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 68.0;
}

- (nonnull UITableViewCell *)tableView:(nonnull UITableView *)tableView cellForRowAtIndexPath:(nonnull NSIndexPath *)indexPath {
    //  获取单元格
    XTagItemCell * cell = [tableView dequeueReusableCellWithIdentifier:kCellId];

    //（寻找标识符为cellid并且没被用到的cell用于重用）
    if(cell == nil){
        NSBundle * bundle = [NSBundle mainBundle];
        cell = (XTagItemCell *)[bundle loadNibNamed:kCellNib owner:self options:nil];
    }

    //  获取数据
    TagItem * item =  AppDelegate.rfidManager.listTag[indexPath.row];

    //  有效就设置值
    if(cell != nil){
        cell.label_index.text                  = [NSString stringWithFormat:@"%ld",(indexPath.row + 1)];
        cell.label_title.text                  = [item getTextEpc];
        cell.label_pc.text                     = [NSString stringWithFormat:@"PC:%04X",item.pc];
        cell.label_crc.text                    = [NSString stringWithFormat:@"CRC:%04X",item.crc];
        cell.label_count.text                  = [NSString stringWithFormat:@"%ld",(long)item.count];

        // 显示序号的背景色和形状
        cell.label_index.backgroundColor        = [item getColorByEpc];
        cell.label_index.clipsToBounds          = true;
        cell.label_index.layer.masksToBounds    = true;
        cell.label_index.layer.cornerRadius     = 10;
        cell.label_index.layer.borderWidth      = 1;
        cell.label_index.layer.borderColor      = UIColor.darkGrayColor.CGColor;
        cell.label_index.textColor              = UIColor.darkTextColor;
        cell.label_index.shadowColor            = UIColor.whiteColor;
        cell.label_index.shadowOffset           = CGSizeMake(1, 1);
    }

    return cell;
}


/*
 #pragma mark - Navigation

 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */


@end
