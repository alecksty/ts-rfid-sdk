//
//  BleDeviceController.h
//  FastRfidOC
//
//  Created by shitanyu on 2018/10/24.
//  Copyright © 2018 shitanyu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <RfidLib/RfidLib.h>

enum{
    BLE_MSG_ERROR               = -1, // 错误
    BLE_MSG_IDLE                = 0, // 空闲
    BLE_MSG_SCAN_START          = 1, // 开始扫描
    BLE_MSG_SCAN_STOP           = 2, // 停止扫描
    BLE_MSG_UPDATE_DEVICE       = 3, // 更新设备
    BLE_MSG_UPDATE_SERVICE      = 4, // 更新服务
    BLE_MSG_UPDATE_CHARACT      = 5, // 更新特征
    BLE_MSG_UPDATE_DESCRIPT     = 6, // 更新描述
    BLE_MSG_CONNECT_DEVICE      = 7, // 连接设备
    BLE_MSG_DISCONNECT_DEVICE   = 8, // 断开连接
    BLE_MSG_MESSAGE             = 9, // 完成
    BLE_MSG_UART_INIT_DONE      = 10, // 完成
};

enum{
    ///  状态
    BLE_STATE_UNKNOW            = 0, // 未知
    BLE_STATE_START             = 1, // 开始
    BLE_STATE_DOING             = 2, // 执行
    BLE_STATE_SUCCESS           = 3, // 成功
    BLE_STATE_FAILED            = 4, // 失败
};

NS_ASSUME_NONNULL_BEGIN

@interface XDeviceController : UITableViewController <BleManagerDelegate>

@end

NS_ASSUME_NONNULL_END
