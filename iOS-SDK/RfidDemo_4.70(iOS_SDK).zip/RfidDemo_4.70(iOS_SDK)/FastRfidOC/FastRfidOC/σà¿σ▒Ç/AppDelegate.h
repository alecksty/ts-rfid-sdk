//
//  AppDelegate.h
//  FastRfidOC
//
//  Created by shitanyu on 2018/10/24.
//  Copyright © 2018 shitanyu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <RfidLib/RfidLib.h>
#import <CoreData/CoreData.h>
#import <CoreBluetooth/CoreBluetooth.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (readonly, strong) NSPersistentContainer *persistentContainer;

- (void)saveContext;

#pragma mark - 必须实现的接口
/**
 标签 - 管理器
 */
+(RfidManager *)rfidManager;

/**
 端口 - 管理器
 */
+(PortManager *)portManager;

@end

