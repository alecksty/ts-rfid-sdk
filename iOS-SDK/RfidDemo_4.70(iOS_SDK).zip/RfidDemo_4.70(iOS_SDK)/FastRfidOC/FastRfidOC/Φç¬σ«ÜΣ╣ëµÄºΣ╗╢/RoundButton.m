//
//  RoundButton.m
//  FastRfidOC
//
//  Created by shitanyu on 2018/10/24.
//  Copyright © 2018 shitanyu. All rights reserved.
//

#import "RoundButton.h"

@implementation RoundButton

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

-(void)layoutSubviews{
    //  定义渐变的颜色（3种彩虹色）
//    NSArray * gradientColors = [(void)(UIColor.darkGrayColor.CGColor),
//                                (void)(UIColor.grayColor.CGColor),
//                                UIColor.lightGrayColor.CGColor];
//
//    //  定义每种颜色所在的位置
//    let gradientLocations:[NSNumber] = [0.0, 0.5, 1.0];
//
//    //  创建CAGradientLayer对象并设置参数
//    let gradientLayer               = CAGradientLayer(layer:layer);
//    gradientLayer.colors            = gradientColors;
//    gradientLayer.locations         = gradientLocations;
//
//    //  设置渲染的起始结束位置（横向渐变）
//    gradientLayer.startPoint        = CGPoint(x: 0, y: 1);
//    gradientLayer.endPoint          = CGPoint(x: 0, y: 0);
//    gradientLayer.borderColor       = UIColor.gray.cgColor;
//    gradientLayer.borderWidth       = 1;
//    gradientLayer.cornerRadius      = 21;
//
//    //  设置其CAGradientLayer对象的frame，并插入view的layer
//    gradientLayer.frame             = CGRect(origin: CGPoint(x:0,y:0), size: self.bounds.size);
//    gradientLayer.frame.offsetBy(dx: gradientLayer.frame.minX, dy: gradientLayer.frame.minY);
//
//    //  插入控件
//    //self.layer.insertSublayer(gradientLayer,at:0);
//    //NSLog("layers count : %d\n",(self.layer.sublayers?.count)!);
//    //if(self.layer.sublayers?.count)
//
//    if(self.layer.sublayers != nil){
//        //  超过一个，先要去掉前面的。
//        if(self.layer.sublayers.count > 1){
//            [self.layer.sublayers removeAt: 0];
//        }
//        self.layer.insertSublayer(gradientLayer,at:0);
//    }
}

@end
