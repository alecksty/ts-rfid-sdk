//
//  RoundButton.swift
//  FastRfid
//
//  Created by shitanyu on 2018/6/11.
//  Copyright © 2018年 shitanyu. All rights reserved.
//

import Foundation
import UIKit

class RoundButton: UIButton {

    override func draw(_ rect: CGRect) {
        super.draw(rect);
    }

    override func layoutSubviews() {
        super.layoutSubviews()

        //  定义渐变的颜色（3种彩虹色）
        let gradientColors = [UIColor.darkGray.cgColor,
                              UIColor.gray.cgColor,
                              UIColor.lightGray.cgColor]

        //  定义每种颜色所在的位置
        let gradientLocations:[NSNumber] = [0.0, 0.5, 1.0]

        //  创建CAGradientLayer对象并设置参数
        let gradientLayer               = CAGradientLayer(layer:layer)
        gradientLayer.colors            = gradientColors
        gradientLayer.locations         = gradientLocations

        //  设置渲染的起始结束位置（横向渐变）
        gradientLayer.startPoint        = CGPoint(x: 0, y: 1)
        gradientLayer.endPoint          = CGPoint(x: 0, y: 0)
        gradientLayer.borderColor       = UIColor.gray.cgColor;
        gradientLayer.borderWidth       = 1;
        gradientLayer.cornerRadius      = 21

        //  设置其CAGradientLayer对象的frame，并插入view的layer
        gradientLayer.frame             = CGRect(origin: CGPoint(x:0,y:0), size: self.bounds.size)
        gradientLayer.frame.offsetBy(dx: gradientLayer.frame.minX, dy: gradientLayer.frame.minY)

        //  插入控件
        //self.layer.insertSublayer(gradientLayer,at:0);
        //NSLog("layers count : %d\n",(self.layer.sublayers?.count)!);
        //if(self.layer.sublayers?.count)

        if(self.layer.sublayers != nil){
            //  超过一个，先要去掉前面的。
            if(self.layer.sublayers!.count > 1){
                self.layer.sublayers?.remove(at: 0);
            }
            self.layer.insertSublayer(gradientLayer,at:0);
        }
    }
}
