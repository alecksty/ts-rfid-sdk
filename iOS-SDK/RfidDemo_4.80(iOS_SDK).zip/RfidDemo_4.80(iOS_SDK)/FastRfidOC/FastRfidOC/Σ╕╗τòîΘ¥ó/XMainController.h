//
//  MainController.h
//  FastRfidOC
//
//  Created by shitanyu on 2018/10/24.
//  Copyright © 2018 shitanyu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <RfidLib/RfidLib.h>

NS_ASSUME_NONNULL_BEGIN

@interface XMainController : UIViewController <UITableViewDelegate,UITableViewDataSource,RfidEvent,PortEvent>

@property (weak, nonatomic) IBOutlet UIButton *button_export;
@property (weak, nonatomic) IBOutlet UIButton *button_setup;
@property (weak, nonatomic) IBOutlet UIButton *button_start;

@property (weak, nonatomic) IBOutlet UILabel *label_count;
@property (weak, nonatomic) IBOutlet UILabel *label_rssi;

@property (weak, nonatomic) IBOutlet UITableView *table_tags;

@end

NS_ASSUME_NONNULL_END
