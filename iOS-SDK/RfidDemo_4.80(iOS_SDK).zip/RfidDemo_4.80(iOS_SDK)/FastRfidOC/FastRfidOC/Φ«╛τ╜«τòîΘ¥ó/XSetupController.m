//
//  SetupController.m
//  FastRfidOC
//
//  Created by shitanyu on 2018/10/24.
//  Copyright © 2018 shitanyu. All rights reserved.
//

#import "AboutController.h"
#import "XSetupController.h"
#import "XDeviceController.h"
#import "XTagItemCell.h"
#import "AppDelegate.h"

///-----------------------------------------------------------------------------
/// 设置序号
///-----------------------------------------------------------------------------
enum emSetupID{
    //  接口
    XIETM_USART    = 1000,
    XIETM_BLE      = 1001,
    XIETM_WIFI     = 1002,
    XIETM_UART     = 1003,
    XIETM_USB      = 1004,

    //  设备
    XIETM_RX_POWER = 2003,
    XIETM_AREA     = 2004,
    XIETM_FREQ     = 2005,
    XIETM_SKIP     = 2006,
    XIETM_TX_POWER = 2007,

    //  操作
    XIETM_SHAKE    = 3008,
    XIETM_SOUND    = 3009,
    XIETM_TIMES    = 3010,

    //  其他
    XIETM_RESET    = 4010,
    XIETM_DEBUG    = 4011,
    XIETM_ABOUT    = 4012,
};

//  字符串数组
static NSArray *  _dataItems;
//  单元格样式
static UITableViewCellStyle _cellStyle;
//  设置管理器
static XSetupManager * _setupManager = nil;

@interface XSetupController ()

@end

@implementation XSetupController

//    MARK: - 函数接口 -

///-------------------------------------------------------------------------
/// 加载数据
///-------------------------------------------------------------------------
-(void) viewDidLoad {

    // Uncomment the following line to preserve selection between presentations
    //self.clearsSelectionOnViewWillAppear = false;
    [self setClearsSelectionOnViewWillAppear:false];

    //  返回键
    UIBarButtonItem * returnItem = [[UIBarButtonItem alloc] initWithTitle:@"返回"
                                                                    style:UIBarButtonItemStylePlain
                                                                   target:self
                                                                   action:@selector(action_back)];

    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    self.navigationItem.leftBarButtonItem = returnItem;
    //  加载列表
    [self initList];
}

///-------------------------------------------------------------------------
/// 列表初始化
///-------------------------------------------------------------------------
//  输出功率

-(void) initList{
    //
    NSArray * arraySmart        = [NSArray arrayWithObjects:@"高",@"中",@"低",nil];
    //
    NSArray * arrayArea         = [NSArray arrayWithObjects:@"中国800Mhz",@"中国900Mhz",@"美国",@"欧洲",@"韩国",nil];
    //  输出功率
    NSArray *  arrayTxPower     = [NSArray arrayWithObjects:@"26 dB", @"20 dB", @"18.5 dB", @"17 dB", @"15.5 dB", @"14 dB", @"12.5 dB",nil];
    //  每秒钟次数
    NSArray *  arrayTimesSec    = [NSArray arrayWithObjects:@"100次", @"50次", @"20次", @"10次",nil];
    //
    BleManager * bleMan        = [AppDelegate.portManager getBleManager];
    //  设备
    CBPeripheral * device        = bleMan.uartPeripheral;
    //  设备名
    NSString * devName          = @"未连接";

    //  有设备名
    if (device != nil) {
        devName = device.name;
    }

    //  界面加载
    UIStoryboard * storyboard      = [UIStoryboard storyboardWithName:@"Main" bundle:nil];

    XDeviceController * intentBle  = (XDeviceController * )[storyboard instantiateViewControllerWithIdentifier:@"XDeviceController"];

    AboutController * intentAbout  = (AboutController * )[storyboard instantiateViewControllerWithIdentifier:@"AboutController"];

    //  分配列表
    if(_setupManager == nil){
        _setupManager = [[XSetupManager alloc] init];
    }

    [_setupManager clear];

    //  添加设备组
    [_setupManager add:[[XSetupItem alloc] init:@"接口"]];
    [_setupManager add:[[XSetupItem alloc] init:XIETM_BLE title:@"蓝牙" intent:intentBle]];
    [_setupManager add:[[XSetupItem alloc] init:XIETM_WIFI title:@"网络" text:@"未连接" intent:intentBle]];
    [_setupManager add:[[XSetupItem alloc] init:XIETM_USB title:@"USB" text:@"未连接" intent:intentBle]];
    //[_setupManager add:[[XSetupItem alloc] init:XIETM_USART title:@"串口" text:@"未连接"]];

    //  添加设备属性
    [_setupManager add:[[XSetupItem alloc] init:@"设备"]];
     [_setupManager add:[[XSetupItem alloc] init:XIETM_RX_POWER title:@"灵敏度" pos:0 array:arraySmart]];
     [_setupManager add:[[XSetupItem alloc] init:XIETM_AREA title:@"区域" pos:0 array:arrayArea]];
     [_setupManager add:[[XSetupItem alloc] init:XIETM_SKIP title:@"跳频" onoff:true]];
     [_setupManager add:[[XSetupItem alloc] init:XIETM_TX_POWER title:@"功率" pos:0 array:arrayTxPower]];

     [_setupManager add:[[XSetupItem alloc] init:@"操作"]];
     [_setupManager add:[[XSetupItem alloc] init:XIETM_SOUND title:@"声音" onoff: false]];
     [_setupManager add:[[XSetupItem alloc] init:XIETM_SHAKE title:@"震动" onoff: false]];
     [_setupManager add:[[XSetupItem alloc] init:XIETM_SHAKE title:@"每秒次数" pos:1 array:arrayTimesSec]];

     [_setupManager add:[[XSetupItem alloc] init:@"其他"]];
     //[_setupManager add:[[XSetupItem alloc] init:XIETM_RESET title:@"复位"]];
     [_setupManager add:[[XSetupItem alloc] init:XIETM_ABOUT title:@"关于" intent:intentAbout]];

    // 设置管理器关联
     //[_setupManager setTableView:tableView :self:self)];

    [_setupManager setTableView:self.tableView :self :self];
}

-(IBAction)action_back
{
    [self dismissViewControllerAnimated:true completion:nil];
}

/**
 * 设置响应
 *
 * - parameter msg   : 消息
 * - parameter item  : 设置项目
 * - parameter id    : 项目标号
 * - parameter on    : 逻辑值
 * - parameter pos   : 选择值
 * - parameter text  : 文本值
 * - parameter param : 参数
 */
-(void)OnSetupEventWithMsg:(NSInteger)msg
                      item:(XSetupItem *)item
                        id:(NSInteger)id
                        on:(BOOL)on
                       pos:(NSInteger)pos
                      text:(NSString *)text
                     param:(id)param
{
    if(on){
        NSLog(@"msg:%ld,item:%@,id:%ld,on:YES,pos:%d\n",(long)msg,item,(long)id,pos);
    }else{
        NSLog(@"msg:%ld,item:%@,id:%ld,on:NO,pos:%d\n",(long)msg,item,(long)id,pos);
    }

    switch (id) {
        case XIETM_USART:
            break;

        case XIETM_BLE:
            break;

        case XIETM_WIFI:
            break;

            //  灵敏度
        case XIETM_RX_POWER:
            break;

            //===============
            //  区域
            //===============
        case XIETM_AREA:
            //Log.d(TAG,"区域:" + pos);
            //rfid_putArray(bytes:RfidMake.cmd.set_region(region: UInt8(1 + pos)));
            break;

            //===============
            //  频率
            //===============
        case XIETM_FREQ:
            //Log.d(TAG,"频率:" + pos);
            //rfid_putArray(bytes:RfidMake.cmd.set_tx_power(power: UInt16(pos & 0xffff)));
            break;

            //===============
            //  跳频
            //===============
        case XIETM_SKIP:
            //Log.d(TAG,"跳频:" + on);
            //rfid_putArray(bytes: RfidMake.cmd.set_auto(auto: on));
            break;

            //===============
            //  功率
            //===============
        case XIETM_TX_POWER:
            //Log.d(TAG,"功率:" + pos);
            //rfid_putArray(bytes: RfidMake.cmd.set_tx_power(power: UInt16(pos)));
            {
                UInt16 arrPower[] = {2600, 2000, 1850, 1700, 1550, 1400, 1250};
                BaseReader * reader = [AppDelegate.rfidManager getReader];
                [self rfid_putArray:[reader.cmd rfid_set_tx_power:arrPower[pos]]];
            }
            break;

            //===============
            //  声音
            //===============
        case XIETM_SOUND:
            break;

            //===============
            //  震动
            //===============
        case XIETM_SHAKE:
            break;

            //===============
            //  次数
            //===============
        case XIETM_TIMES:
            break;

            //===============
            //  复位
            //===============
        case XIETM_RESET:
            break;

            //===============
            //  调试
            //===============
        case XIETM_DEBUG:
            break;

            //===============
            //  关于
            //===============
        case XIETM_ABOUT:
            break;

        default:
            break;
    }
}

///
/// 输出数据
///
-(void)rfid_putArray:(NSArray<NSNumber *> *) bytes
{
    [[AppDelegate.portManager getPort] sendData:bytes];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
