//
//  BleDeviceController.m
//  FastRfidOC
//
//  Created by shitanyu on 2018/10/24.
//  Copyright © 2018 shitanyu. All rights reserved.
//
#import "AppDelegate.h"
#import "XDeviceController.h"

#define DEBUG       (YES)

/// 单元名称
static NSString * kCellId = @"BleDeviceCell";
/// 蓝牙管理器
static BleManager * bleManager = NULL;

///
@interface XDeviceController ()

@end

@implementation XDeviceController

///-----------------------------------------------------------------------------
///  界面加载
///-----------------------------------------------------------------------------
-(void)viewDidLoad{
    [super viewDidLoad];

    /// 获取蓝牙管理器
    bleManager = [AppDelegate.portManager getBleManager];
    /// 蓝牙响应消息
    bleManager.delegate = self;
    /// 注册类
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:kCellId];
    //  标题
    self.title = @"蓝牙";

    // 打开扫描
    //[bleManager scanWithOnoff:YES];
    // 这是蓝牙控制中心管理器，可以做任何控制！
    //bleManager.centralManager
}

-(void)viewDidDisappear:(BOOL)animated{
    [bleManager scanWithOnoff:NO];
}
//    MARK: - view event -

-(void)viewDidAppear:(BOOL)animated{

    if(DEBUG){
        NSLog(@"viewDidAppear\n");
    }
    //  获取指针
    bleManager             = [AppDelegate.portManager getBleManager];
    //  蓝牙响应消息
    bleManager.delegate    = self;
}

// MARK: - Table view data source

//
//  分组
//
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

//
//  行数
//
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    // #warning Incomplete implementation, return the number of rows
    return bleManager.arrayPeripherals.count;
}

//
// 单元格
//
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    UITableViewCell * cell = [tableView dequeueReusableCellWithIdentifier:kCellId forIndexPath:indexPath];
    //var cell:UITableViewCell? = tableView.dequeueReusableCell(withIdentifier: kCellId, for: indexPath)

    if(cell == nil){
        cell = [[UITableViewCell alloc] init];
    }

    //  设备
    CBPeripheral * dev = (CBPeripheral *)bleManager.arrayPeripherals[indexPath.row];
    //  设备名称
    cell.textLabel.text = dev.name;

    //  设备有效
    if(bleManager.uartPeripheral != nil){
        //  设备相等
        if([bleManager.uartPeripheral isEqual:dev]){
            cell.textLabel.textColor = UIColor.orangeColor;
        }else{
            cell.textLabel.textColor = UIColor.darkGrayColor;
        }
    }else{
        cell.textLabel.textColor = UIColor.darkGrayColor;
    }

    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

    if(DEBUG){
        NSLog(@"选中数据:%ld\n",(long)indexPath.row);
    }

    if(bleManager != nil){
        //  当前设备
        CBPeripheral * dev = bleManager.arrayPeripherals[indexPath.row];
        //  连接到设备!
        [bleManager connect:dev];
    }
}

/**
 接收

 @param dev 设备
 @param data 数据
 @param error 错误
 */
-(void)onBleRxDataWithDev:(CBPeripheral *)dev data:(NSArray<NSNumber *> *)data error:(NSError *)error{
   [AppDelegate.rfidManager dataIn:data];
}

//    MARK: - 蓝牙管理器代理 -
-(void)onBleEventWithDev:(CBPeripheral *)dev msg:(NSInteger)msg state:(NSInteger)state text:(NSString *)text{

    if(text != nil){
        [[MsgMake getInstance]  show:MessageTypeMSG_NOTIFY :text :1.0];
    }

    switch (msg) {
    //===========
    //  连接
    //===========
    case BLE_MSG_CONNECT_DEVICE:
        if(state == BleManager.BLE_STATE_START){
            if(dev != nil){
                [[MsgMake getInstance] show:MessageTypeMSG_NOTIFY :[NSString stringWithFormat:@"连接到设备:%@",dev.name] :3.0];
            }
        }else if(state == BleManager.BLE_STATE_DOING){
            [[MsgMake getInstance] show:MessageTypeMSG_NOTIFY :@"连接设备中..." :1.0];
        }else if(state == BleManager.BLE_STATE_FAILED){
            [[MsgMake getInstance] show:MessageTypeMSG_NOTIFY :@"连接设备失败！" :1.0];
        }
        break;

    //===========
    //  断开
    //===========
    case BLE_MSG_DISCONNECT_DEVICE:
        if(state == BleManager.BLE_STATE_START){
            if(dev != nil){
                [[MsgMake getInstance] show:MessageTypeMSG_NOTIFY :[NSString stringWithFormat:@"断开设备%@",dev.name] :1.0];
            }
        }else if(state == BleManager.BLE_STATE_DOING){
            [[MsgMake getInstance] show:MessageTypeMSG_NOTIFY :@"断开设备中..." :1.0];
        }else if(state == BleManager.BLE_STATE_FAILED){
            [[MsgMake getInstance] show:MessageTypeMSG_NOTIFY :@"断开设备失败!" :1.0];
        }
            break;

        //  更新
    case BLE_MSG_UPDATE_DEVICE:
            [self.tableView reloadData];
            break;

    case BLE_MSG_UPDATE_SERVICE:
            [self.tableView reloadData];
            break;

    case BLE_MSG_UPDATE_CHARACT:
            [self.tableView reloadData];
            break;

    case BLE_MSG_UPDATE_DESCRIPT:
            [self.tableView reloadData];
            break;

    default:
            break;
    }
}

@end
