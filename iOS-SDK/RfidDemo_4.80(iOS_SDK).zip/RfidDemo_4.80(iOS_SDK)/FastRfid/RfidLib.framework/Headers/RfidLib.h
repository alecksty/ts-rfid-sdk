//
//  RfidLib.h
//  RfidLib
//
//  Created by shitanyu on 2018/9/7.
//  Copyright © 2018年 shitanyu. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for RfidLib.
FOUNDATION_EXPORT double RfidLibVersionNumber;

//! Project version string for RfidLib.
FOUNDATION_EXPORT const unsigned char RfidLibVersionString[];

// In this header, you should import all the public headers of your framework using statements like
//#import <RfidLib/PublicHeader.h>
#import <RfidLib/JKAlertDialog.h>
