//
//  ViewController.swift
//  FastRfid
//
//  Created by shitanyu on 2018/6/10.
//  Copyright © 2018年 shitanyu. All rights reserved.
//

import UIKit
import CoreBluetooth
import RfidLib
import MessageUI
import AudioToolbox
import CoreAudio
import AVKit

///=============================================================================
///  主界面 - 控制器
///=============================================================================
class MainController : UIViewController
    ,UITableViewDelegate
    ,UITableViewDataSource
    ,MFMailComposeViewControllerDelegate
    ,UIDocumentInteractionControllerDelegate
    ,PortEvent
    ,RfidEvent
{
    //#define DEBUG_LONG_TEXT false

    // MARK: - 常量
    //  调试开关
    private let DEBUG       = AppDelegate.DEBUG;
    private let kCellNib    = "TagItemCell";
    private let kCellId     = "TagItemId";

    // MARK: - 界面关联
    /// - 信号
    @IBOutlet weak var label_rssi           : UILabel!
    /// - 数量
    @IBOutlet weak var label_count          : UILabel!
    /// - 列表
    @IBOutlet weak var table_tags           : UITableView!
    /// - 导出
    @IBOutlet weak var button_export        : UIButton!
    /// - 开始
    @IBOutlet weak var button_start         : RoundButton!
    /// - 设置
    @IBOutlet weak var button_setup         : UIButton!
    /// - 电量
    @IBOutlet weak var label_percent        : UILabel!
    /// - 电压
    @IBOutlet weak var label_volatile       : UILabel!
    
    // MARK: - 本地变量
    /// 背景
    private var viewBackground              : BackgroundView?;
    /// 线程
    private static var threadMain           : Thread?;
    /// 标签列表
    private static var list : Array<TagItem> = Array<TagItem>();

    ///  分享接口 - 此变量必须持久，否则界面会消失!
    private var doc : UIDocumentInteractionController?;

    // MARK: - 消息线程
    ///-------------------------------------------------------------------------
    /// 线程
    ///
    /// - Parameter obj: 参数
    ///-------------------------------------------------------------------------
    @objc fileprivate func threadRunLoop(){

        while(AppDelegate.rfidManager != nil){
            /// 读写器
            let reader = AppDelegate.rfidManager!.getReader();
            //  开始？
            if(AppDelegate.rfidManager!.isRunning){
                if(reader!.set!.times < 1){
                    reader!.set!.times = 1;
                }
                /// 写数据
                AppDelegate.portWrite(reader!.cmd!.rfid_inventory(UInt16(reader!.set!.times))!);
            }

            //  休眠20ms
            Thread.sleep(forTimeInterval: 0.02);
        }
    }

    ///-------------------------------------------------------------------------
    ///  状态栏颜色
    ///-------------------------------------------------------------------------
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }

    //    MARK: - 界面事件
    ///-------------------------------------------------------------------------
    /// 加载
    ///-------------------------------------------------------------------------
    override func viewDidLoad() {
        super.viewDidLoad()

        //  自定义背景
        self.viewBackground                 = BackgroundView(frame:self.view.frame);
        //  使用背景
        self.table_tags.backgroundView = self.viewBackground;
        //  消息接口
        self.table_tags.delegate       = self;
        //  数据源
        self.table_tags.dataSource     = self;
        //  注册单元格
        self.table_tags.register(UINib(nibName:kCellNib, bundle:.main),forCellReuseIdentifier:kCellId);

        //  分配线程
        if(MainController.threadMain == nil){
            MainController.threadMain       = Thread(target: self, selector: #selector(threadRunLoop), object: nil);
            MainController.threadMain!.name = "主线程";
        }

        //  更新线程
        if(!(MainController.threadMain?.isExecuting)!){
            MainController.threadMain!.start();
        }

        //  添加长按
        addLongPressGestureRecognizer();

        //  读取设置
        TagItem.setupUpdate(false);

        #if DEBUG_LONG_TEXT
        // 加载数据
        ReloadDatas();
        #endif //DEBUG_LONG_TEXT

        //playSound();
    }

    /**
        * 电池百分比
        * @param activity : 界面
        * @return : 百分比
        */
    func getBatteryPercent(vol:Int)->Int {
        // 最低1.6V
       let VOL_MIN = 160;
        // 最高2.1V
       let VOL_MAX = 210;
        //
       var level   = vol;
        //
       if (level > 0) {
           if (level < VOL_MIN) {
               level = 1;
           } else if (level > VOL_MAX) {
               level = 100;
           } else {
               level = (level - VOL_MIN) * 100 / (VOL_MAX - VOL_MIN);
           }
       }
       return level;
    }

    ///-------------------------------------------------------------------------
    /// 输出
    ///-------------------------------------------------------------------------
    func addLongPressGestureRecognizer() {
        let longPress = UILongPressGestureRecognizer(target: self, action: #selector(self.longPressClick));
        self.button_start.isUserInteractionEnabled = true;
        self.button_start.addGestureRecognizer(longPress);
    }

    ///-------------------------------------------------------------------------
    /// 输出
    ///-------------------------------------------------------------------------
//    func addPressGestureRecognizer() {
//        let longPress = UIPressGestureRecognizer(target: self, action: #selector(self.longPressClick));
//        self.button_start.isUserInteractionEnabled = true;
//        self.button_start.addGestureRecognizer(longPress);
//    }

    ///-------------------------------------------------------------------------
    /// 长按处理
    ///-------------------------------------------------------------------------
    @objc func longPressClick() {
        AppDelegate.rfidManager!.cleanCmd();
        AppDelegate.rfidManager!.clear();
        ReloadDatas();
        if(DEBUG){
            print("longPressClick\n");
        }
    }

    ///-------------------------------------------------------------------------
    /// 触摸
    ///-------------------------------------------------------------------------
    @IBAction func OnTouchTotal(){
        AppDelegate.rfidManager!.cleanCmd();
        AppDelegate.rfidManager!.clear();
        ReloadDatas();
        if(DEBUG){
            print("longPressClick\n");
        }
    }

    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isToolbarHidden = true;
        self.navigationController?.isNavigationBarHidden = true;
        //self.navigationController?.isEditing = false;
        self.navigationController?.becomeFirstResponder();
        /// 更新按键
        updateStartStop();
    }

    ///-------------------------------------------------------------------------
    /// 激活
    ///-------------------------------------------------------------------------
    override func viewDidAppear(_ animated: Bool) {
        /// 消息接口
        AppDelegate.rfidManager!.event = self;
        ///  读写器
        let reader = AppDelegate.rfidManager!.getReader();
        ///  应答接口
        reader!.ack!.setEvent(self);
        /// 检查连接
        if(!AppDelegate.portManager!.getPort().isConnected()){
            //  语言转换
            let s = NSLocalizedString("DEVICE NOT CONNECTED", comment: "设备没有连接,请先连接设备!");
            //  消息提示
            _ = MsgMake(MessageType.MSG_NOTIFY,s, 3.0);
        }
        /// 更新按键
        updateStartStop();
    }

    ///-------------------------------------------------------------------------
    ///  内存警告
    ///-------------------------------------------------------------------------
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    ///-------------------------------------------------------------------------
    /// 收到数据
    ///
    /// - Parameters:
    ///   - data    : 数据
    ///   - error   : 错误
    ///-------------------------------------------------------------------------
    func onReceive(_ data: [UInt8], _ error: Any?) {
        /// 数据导入
        if(AppDelegate.rfidManager != nil){
            AppDelegate.rfidManager!.dataIn(data);
        }
    }

    //  MARK: - 导出数据

    ///-------------------------------------------------------------------------
    /// 导出数据
    ///-------------------------------------------------------------------------
    @IBAction func doExport(_ sender: Any) {

        if(DEBUG){
            print("导出");
        }
        //  语言转换
        let strExport       = NSLocalizedString("EXPORT", comment: "导出");
        let strExportMsg    = NSLocalizedString("EXPORT LIST", comment: "导出数据文件");
        let strCancel       = NSLocalizedString("CANCEL", comment: "取消");
        let strExportFile   = NSLocalizedString("EXPORT TO FILE", comment: "导出到文件");
        let strExportEMail  = NSLocalizedString("EXPORT TO EMAIL", comment: "导出到邮件");
        let strExportShare  = NSLocalizedString("EXPORT TO SHARE", comment: "导出到分享");

        //  下面这段iPad上无法执行
        let alert           = UIAlertController(title: strExport, message: strExportMsg,preferredStyle: .actionSheet);
        //  取消
        let cancelAction    = UIAlertAction(title: strCancel, style: .cancel, handler: nil);
        //  导出文件 (1)
        let expFileAction   = UIAlertAction(title: strExportFile, style: .default, handler: {(a:UIAlertAction)in self.dialogCall(id:1);});
        //  导出邮件 (2)
        let expMailAction   = UIAlertAction(title: strExportEMail, style: .default, handler: {(a:UIAlertAction)in self.dialogCall(id:2);});
        //  导出分享 (3)
        let expShareAction  = UIAlertAction(title: strExportShare,  style: .default, handler: {(a:UIAlertAction)in self.dialogCall(id:3);});

        alert.addAction(cancelAction);
        alert.addAction(expFileAction);
        alert.addAction(expMailAction);
        alert.addAction(expShareAction);

        //  这个在iPad上没有！
        if alert.popoverPresentationController != nil {
            alert.popoverPresentationController!.sourceView = sender as? UIView
            alert.popoverPresentationController!.sourceRect = (sender as AnyObject).bounds
            self.present(alert, animated: true, completion: nil)
        }else{
            self.present(alert, animated: true, completion: nil)
        }
    }

    ///-------------------------------------------------------------------------
    /// 对话框回调
    ///
    /// - Parameter id: 序号
    ///-------------------------------------------------------------------------
    private func dialogCall(id:Int){
        let strList = "list.csv";
        var strPath = "";

        if(DEBUG){
            NSLog("dialogCall(%d)\n",id);
        }

        switch(id){
            //==============
            //  取消
            //==============
        case 0:
            break;

            //==============
            //  导出文件
            //==============
        case 1:
            strPath     = AppDelegate.rfidManager!.exportToFile(strList)!;
            let alert   = UIAlertController(title: NSLocalizedString("MESSAGE", comment: "提示"),
                                            message: NSLocalizedString("MAKE LIST FILE", comment: "已经生成数据文件 : ") + strPath,
                                            preferredStyle: .alert);

            alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "确定"), style: .cancel, handler: nil));

            self.present(alert, animated: true, completion: nil)
            break;

            //==============
            //  导出到MAIL
            //==============
        case 2:
            strPath     = AppDelegate.rfidManager!.exportToFile(strList)!;
            sendWithMail(file: strPath);
            break;

            //==============
            //  导出分享
            //==============
        case 3:
            //  分享文件路径
            strPath = AppDelegate.rfidManager!.exportToFile(strList)!;
            //  转换成链接
            let url = URL(fileURLWithPath: strPath);
            //  生成分享
            doc = UIDocumentInteractionController(url: url);
            //  分享代理
            doc!.delegate = self;
            //  推出界面
            doc!.presentOpenInMenu(from: CGRect.zero, in: self.view, animated: true);
            break;

        default:
            break;
        }
    }

    ///-------------------------------------------------------------------------
    /// 邮件发送文件
    ///
    /// - Parameter file: 文件
    ///-------------------------------------------------------------------------
    func sendWithMail(file:String) {
        //  首先要判断设备具不具备发送邮件功能
        if MFMailComposeViewController.canSendMail(){
            //  邮件控制器
            let controller = MFMailComposeViewController()
            //  设置代理
            controller.mailComposeDelegate = self;
            //  设置主题
            controller.setSubject("UHF RFID TAGS DATA");
            //  设置收件人
            controller.setToRecipients(["SomeOne@163.com"]);
            //  添加附件
            let url = URL(fileURLWithPath: file);
            //  数据
            let data = try! Data(contentsOf: url);
            //  附加
            controller.addAttachmentData(data, mimeType: "text/csv",fileName: "rfid_list.csv");
            //  正文
            controller.setMessageBody("Tag List File", isHTML: false);
            //  打开界面
            self.present(controller, animated: true, completion: nil);
        }else{
            print("本设备不能发送邮件!");
        }
    }

    ///-------------------------------------------------------------------------
    /// 邮件响应
    ///
    /// - Parameters:
    ///   - controller  : 界面
    ///   - result      : 结果
    ///   - error       : 错误
    ///-------------------------------------------------------------------------
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {

        controller.dismiss(animated: true, completion: nil);

        switch result{
        case .sent:
            if(DEBUG){
                print("邮件已发送!");
            }
            do {
                let alert = UIAlertController(title: NSLocalizedString("MESSAGE", comment: "提示"),
                                              message: NSLocalizedString("EMAIL SEND DONE", comment: "邮件已发送！"),
                                              preferredStyle: UIAlertController.Style.alert);

                alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "确定"),
                                              style: .cancel, handler: nil));

                self.present(alert, animated: true, completion: nil);
            }

        case .cancelled:
            if(DEBUG){
                print("邮件已取消!");
            }

        case .saved:
            if(DEBUG){
                print("邮件已保存!");
            }
        case .failed:
            if(DEBUG){
                print("邮件发送失败!");
            }
            do {
                let alert = UIAlertController(title: NSLocalizedString("MESSAGE", comment: "提示"),
                                              message: NSLocalizedString("EMAIL SEND FILED", comment: "邮件发送失败！"),
                                              preferredStyle: UIAlertController.Style.alert);

                alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "确定"),
                                              style: .cancel,
                                              handler: nil));

                self.present(alert, animated: true, completion: nil);
            }

        default:
            break;
        }
    }

    ///-------------------------------------------------------------------------
    /// 开始/停止
    ///-------------------------------------------------------------------------
    @IBAction func doStartStop(_ sender: Any) {
        //  设备没有准备好
        if(!AppDelegate.portManager!.getPort().isConnected()){
            //  提示
            let alert = UIAlertController(title: NSLocalizedString("MESSAGE", comment: "提示"),
                                          message: NSLocalizedString("NO FIND DEVICE",
                                                                     comment: "未连接读写设备,请先连接!\n请在【设置】里的接口选项选择附近设备!"),
                                          preferredStyle: .alert);
            //  添加按钮
            alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "确定"), style: .destructive, handler: nil));
            //  显示提示框
            self.present(alert, animated: true, completion: nil);
        }else{
            //  反向数据
            AppDelegate.rfidManager!.isRunning = !AppDelegate.rfidManager!.isRunning;
        }

        //  显示对应
        updateStartStop();
    }

    ///-------------------------------------------------------------------------
    /// 显示状态
    ///-------------------------------------------------------------------------
    private func updateStartStop(){
        //  显示对应
        if(AppDelegate.rfidManager!.isRunning){
            button_start.setTitle(NSLocalizedString("STOP", comment: "停止"), for:.normal);
        }else{
            button_start.setTitle(NSLocalizedString("START", comment: "开始"), for:.normal);
        }
    }

    ///-------------------------------------------------------------------------
    /// 设置
    ///-------------------------------------------------------------------------
    @IBAction func doSetup(_ sender: Any) {
        /// 。。。。
    }

    ///-------------------------------------------------------------------------
    /// 清空
    ///-------------------------------------------------------------------------
    @IBAction func doClean(_ sender: Any) {
        AppDelegate.rfidManager!.cleanCmd();
        AppDelegate.rfidManager!.clear();
        ReloadDatas();
    }

    // MARK: - RFID事件 -
    ///-------------------------------------------------------------------------
    /// 重新加载
    ///-------------------------------------------------------------------------
    private var updateTimes = 0;
    private func ReloadDatas(){
        let nowDelay    = Date().timeIntervalSince1970;
        let rfid        = AppDelegate.rfidManager;
        let reader      = rfid?.getReader();

        if(oldDelay > nowDelay){
            oldDelay = nowDelay;
        }
        //  时间间隔短，不刷新。
        if(Int((nowDelay - oldDelay) * 1000) < reader!.set!.disp_delay){
            return;
        }
        updateTimes += 1;
        //
        oldDelay = nowDelay;

        //  扫描的标签
        let ls = rfid!.listTag;
        //  清空
        MainController.list.removeAll();
        //  添加
        for i in 0..<ls.count {
            MainController.list.append(ls[i]);
        }

        #if DEBUG_LONG_TEXT
        let a0:[UInt8] = [0x31,0x32,0x33,0x34,0x35,0x36,0x37,0x38,0x39,0x30,0x31,0x32];
        let item0 = TagItem(0,3000,a0,0);
        MainController.list.append(item0);

        let a1:[UInt8] = [0x31,0x32,0x33,0x34,0x35,0x36,0x37,0x38,0x39,0x20,
                          0x31,0x32,0x33,0x34,0x35,0x36,0x37,0x38,0x39,0x20,
                          0x31,0x32,0x33,0x34,0x35,0x36,0x37,0x38,0x39,0x20,
                          0x31,0x32,0x33,0x34,0x35,0x36,0x37,0x38,0x39,0x20,
                          0x31,0x32,0x33,0x34,0x35,0x36,0x37,0x38,0x39,0x20,

                          0x31,0x32,0x33,0x34,0x35,0x36,0x37,0x38,0x39,0x20,
                          0x31,0x32,0x33,0x34,0x35,0x36,0x37,0x38,0x39,0x20,
                          0x31,0x32,0x33,0x34,0x35,0x36,0x37,0x38,0x39,0x20,
                          0x31,0x32,0x33,0x34,0x35,0x36,0x37,0x38,0x39,0x20,
                          0x31,0x32,0x33,0x34,0x35,0x36,0x37,0x38,0x39,0x20,

                          0x31,0x32,0x33,0x34,0x35,0x36,0x37,0x38,0x39,0x20,
                          0x31,0x32,0x33,0x34,0x35,0x36,0x37,0x38,0x39,0x20,
                          0x31,0x32,0x33,0x34,0x35,0x36,0x37,0x38,0x39,0x20,
                          0x31,0x32,0x33,0x34,0x35,0x36,0x37,0x38,0x39,0x20,
                          0x31,0x32,0x33,0x34,0x35,0x36,0x37,0x38,0x39,0x20,];
        
        let item1 = TagItem(0,0,a1,0);
        MainController.list.append(item1);

        let a2:[UInt8] = [1,2,3,4,5,6,7,8];
        let item2 = TagItem(0,0,a2,0);
        MainController.list.append(item2);

        let a3:[UInt8] = [1,2,3,4,5,6,7,8];
        let item3 = TagItem(0,0,a3,0);
        MainController.list.append(item3);

        #endif

        //  刷新
        table_tags.reloadData();

        //  声音
        threadPlaySound();
    }

    //  播放状态
    private var isPlaying = false;
    //  播放
    @objc func mainPlaySound(){
        if(!isPlaying){
            let reader  = AppDelegate.rfidManager?.getReader();
            if(reader != nil){
            let set = reader!.set;
                if(set!.user_sound){
                    //
                    var soundId:SystemSoundID = 0;
                    //  查找资源
                    let path = Bundle.main.path(forResource: "rfid_notify", ofType: "wav");
                    //  路径
                    let baseURL = NSURL(fileURLWithPath: path!);
                    //  创建b服务
                    AudioServicesCreateSystemSoundID(baseURL,&soundId);
                    //  播放完成
                    AudioServicesPlaySystemSoundWithCompletion(soundId) {
                        print("播放完成!\n");
                        self.isPlaying = false;
                        AudioServicesRemoveSystemSoundCompletion(soundId);
                        AudioServicesDisposeSystemSoundID(soundId)
                    }
                }
            }
        }
    }

    /// 线程播放声音
    @objc func threadPlaySound(){
        //  方式1：使用类方法
        Thread.detachNewThreadSelector(#selector(mainPlaySound),toTarget: self, with: nil)
    }

    ///-------------------------------------------------------------------------
    /// RFID 响应事件
    ///
    /// - Parameters:
    ///   - type    : 类型
    ///   - cmd     : 命令
    ///   - para    : 参数
    ///   - obj     : 对象
    ///-------------------------------------------------------------------------
    private var oldDelay:TimeInterval = 0;
    func OnRfidResponse(_ type: Int, _ cmd: Int, _ para: [UInt8]?, _ obj: Any?) {

        //=======================
        //  消息
        //=======================
//        if(DEBUG){
//            if (obj is String) {
//                let s : String = obj as! String;
//                print(String(format:"cmd : %02x - %@\n", cmd,s));
//            }
//        }

        //=======================
        //   错误
        //=======================
        if (type == BaseAck.RESPONSE_TYPE_ERROR) {
            if(cmd == 0xff){

            }else{
                NSLog("ERROR - cmd:%x\n",cmd);
            }
            return;
        }

        switch (cmd) {
        //=======================
        //  收到标签
        //=======================
        case BaseCmd.RFID_CMD_INVENTORY:
            updateList(obj);
            break;

        default:
            if (DEBUG) {
                NSLog("未知命令 cmd : %02x\n",cmd);
            }
            break;
        }
    }
    //  MARK: - 列表 -

    ///-------------------------------------------------------------------------
    /// 更新列表
    ///
    /// - Parameter obj: 对象
    ///-------------------------------------------------------------------------
    private func updateList(_ obj:Any?){

        if(obj == nil){
            return;
        }

        if (obj is TagItem) {
            let tag = obj as! TagItem;
            //  刷新
            ReloadDatas();
            //  强度
            var rssi_n : Int8 = 0;
            //  信号
            if(tag.rssi > 127){
                rssi_n = Int8(0 - (Int(256) - Int(tag.rssi)));
            }else{
                rssi_n = Int8(tag.rssi);
            }
            //  文本
            label_rssi.text = String(format:"%d",Int(rssi_n));
            //  获取计数
            if(AppDelegate.rfidManager != nil){
                label_count.text = String(format:"%d",AppDelegate.rfidManager!.listTag.count);
            }
            
            //  电压
            let level = AppDelegate.rfidManager!.getReader()!.battery;
            
            label_percent.text  = String(format:"%d%%",Int(getBatteryPercent(vol: level)));
            
            label_volatile.text = String(format:"%d.%02dV",Int(level/100),Int(level%100));
            
            //playSound();
        }
    }

    ///
    
    public func playSound() {
        var player :AVAudioPlayer;
        //  地址
        let url = Bundle.main.url(forResource: "rfid_notify", withExtension: "wav");

        do {
            try AVAudioSession.sharedInstance().setCategory(AVAudioSession.Category.playback)
            try AVAudioSession.sharedInstance().setActive(true)
            /* The following line is required for the player to work on iOS 11. Change the file type accordingly*/
            player = try AVAudioPlayer(contentsOf: url!, fileTypeHint: AVFileType.mp3.rawValue)

            /* iOS 10 and earlier require the following line:
             player = try AVAudioPlayer(contentsOf: url, fileTypeHint: AVFileTypeMPEGLayer3) */
//            guard let player = player else {
//                return
//            }
            player.play()
        } catch let error {
            print(error.localizedDescription)
        }
    }

    ///-------------------------------------------------------------------------
    /// 选择行
    ///-------------------------------------------------------------------------
    private var contentUI:ContentController? = nil;

    ///-------------------------------------------------------------------------
    /// 行选择
    ///
    /// - Parameters:
    ///   - tableView: 列表
    ///   - indexPath: 路径
    ///-------------------------------------------------------------------------
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //  获取
        let tag = MainController.list[indexPath.row];
        //  选择
        ContentController.setTagItem(tag);
        //  跳转
        self.performSegue(withIdentifier: "segue_detail", sender: nil);
    }

    ///-------------------------------------------------------------------------
    /// 行高度
    ///-------------------------------------------------------------------------
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {

        let item:TagItem    = (MainController.list[indexPath.row]);
        let text            = item.getTextEpc();
        let labelHeight     = text.getTextHeight(fontSize: 19.0, width: tableView.frame.width - 64 - 50 - 18);

        if(labelHeight + 32 > 68){
            return labelHeight + 32;//24.0;
        }
        return 68.0
    }

    ///-------------------------------------------------------------------------
    ///  单元格
    ///-------------------------------------------------------------------------
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //  获取单元格
        var cell:TagItemCell? = tableView.dequeueReusableCell(withIdentifier:kCellId) as? TagItemCell;
        //  (寻找标识符为cellid并且没被用到的cell用于重用)
        if(cell == nil){
            let mainBundle = Bundle.main
            cell = mainBundle.loadNibNamed(kCellNib, owner: self, options: nil)?.last as? TagItemCell
        }

        //  获取数据
        let item:TagItem = (MainController.list[indexPath.row]);

        //  有效就设置值
        if(cell != nil){

            cell!.backgroundColor = UIColor.clear;

            cell!.label_index.text                   = String(indexPath.row + 1);
            cell!.label_title.text                   = item.getTextEpc();
            // 自动换行，这里最重要
            cell!.label_title.numberOfLines          = 0;

            cell!.label_pc.text                      = String(format: "PC:%04X",item.pc);
            cell!.label_crc.text                     = String(format: "CRC:%04X",item.crc);
            cell!.label_rssi.text                    = String(format: "RSSI:%d dB",0 - (255 - Int(item.rssi) & 0xFF));
            cell!.label_count.text                   = String(format: "%d",item.count);

            // 显示序号的背景色和形状
            if(cell!.label_index != nil){
                cell!.label_index.backgroundColor        = item.getColorByEpc();
                cell!.label_index.clipsToBounds          = true;
                //cell!.label_index.layer.masksToBounds    = true;
                cell!.label_index.layer.cornerRadius     = 10;
                cell!.label_index.layer.borderWidth      = 0.5;
                cell!.label_index.layer.borderColor      = UIColor.gray.cgColor;
                cell!.label_index.textColor              = UIColor.white;
                cell!.label_index.shadowColor            = UIColor.darkGray;
                cell!.label_index.shadowOffset           = CGSize(width:0.5,height:0.5);
            }
        }

        return cell!;
    }

    ///-------------------------------------------------------------------------
    /// 段数量
    ///-------------------------------------------------------------------------
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    ///-------------------------------------------------------------------------
    /// 行数量
    ///-------------------------------------------------------------------------
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return MainController.list.count;
    }
}

