//
//  SetupController.swift
//  FastRfid
//
//  Created by shitanyu on 2018/6/12.
//  Copyright © 2018年 shitanyu. All rights reserved.
//
import UIKit
import RfidLib
import Foundation

//==============================================================================
//  设置界面
//==============================================================================
class SetupListUi: UITableViewController,XSetupDelegate {

    //  字符串数组
    public var _dataItems : [String]?;

    //  单元格样式
    public var _cellStyle : UITableViewCell.CellStyle?;

    //  接口
    private  let XITEM_USART            = 1000;
    private  let XITEM_BLE              = 1001;
    private  let XITEM_WIFI             = 1002;
    private  let XITEM_UART             = 1003;
    private  let XITEM_USB              = 1004;
    //  指令集
    private  let XITEM_INSTRUCTION      = 1100;
    //  设备
    private  let XITEM_RX_POWER         = 2003;
    private  let XITEM_AREA             = 2004;
    private  let XITEM_FREQ             = 2005;
    private  let XITEM_SKIP             = 2006;
    private  let XITEM_TX_POWER         = 2007;

    //  方向
    private  let XITEM_DISP_INVERT      = 2100;
    //  文字 模式
    private  let XITEM_DISP_TEXT        = 2200;
    //  显示 数量
    private  let XITEM_DISP_MAX         = 2300;
    //  显示 延时
    private  let XITEM_DISP_DELAY       = 2400;

    //  操作
    private  let XITEM_SHAKE            = 3008;
    private  let XITEM_SOUND            = 3009;
    private  let XITEM_TIMES            = 3010;

    //  其他
    private  let XITEM_DEBUG            = 4000;
    private  let XITEM_ABOUT            = 4001;

    //  区域
    private let arrayArea  = [
        NSLocalizedString("AREA CN800"  , comment:"中国800Mhz"),
        NSLocalizedString("AREA CN900"  , comment:"中国900Mhz"),
        NSLocalizedString("AREA USA"    , comment:"美国"),
        NSLocalizedString("AREA EROUP"  , comment:"欧洲"),
        NSLocalizedString("AREA KOREA"  , comment:"韩国")
    ];

    //  区域
    private let arrayCmdArea = [1,4,2,3,6];

    //  指令集
    private let arrayInstruct = [
        NSLocalizedString("INSTRUCT R2000"  , comment:"R2000 (H3/H8/R1/R4/R8/D1)"),
        NSLocalizedString("INSTRUCT M100"   , comment:"QM100 (H1/H2/T1)"),
        NSLocalizedString("INSTRUCT PR9200" , comment:"PR9200 (H9)"),
        NSLocalizedString("INSTRUCT SLR5300", comment:"SLR5300 (H5/H6/H7)"),
    ];

    //  每秒次数
    private let arrayTimesSec = ["100","50","20","10","5", "2", "1","0"];

    //  设置管理器
    private var setupManager = XSetupManager();

    //    MARK: - 函数接口 -
    
    /// 状态栏风格
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }

    ///-------------------------------------------------------------------------
    /// 加载数据
    ///-------------------------------------------------------------------------
    override func viewDidLoad() {

        // Uncomment the following line to preserve selection between presentations
        self.clearsSelectionOnViewWillAppear = false

        //  加载列表
        initList();
    }

    //  开始
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isToolbarHidden = true;
        self.navigationController?.isNavigationBarHidden = false;
        self.navigationController?.isEditing = false;
        self.navigationController?.becomeFirstResponder();
    }

    ///
    /// 响应
    ///
    /// - Parameter animated: 动画
    override func viewDidAppear(_ animated: Bool) {
//        self.navigationController?.isToolbarHidden = true;
//        self.navigationController?.isNavigationBarHidden = false;
//        self.navigationController?.isEditing = false;
//        self.navigationController?.becomeFirstResponder();
    }

    ///-------------------------------------------------------------------------
    /// 列表初始化
    ///-------------------------------------------------------------------------
    func initList(){

        //  蓝牙管理器
        let bleMan      = AppDelegate.portManager?.getBleManager();
        //  设备
        let device      = bleMan?.uartPeripheral;
        //  未连接
        let strNone     = NSLocalizedString("NONE", comment:"未连接");
        //  设备名
        var devName     = strNone;
        //  有设备名
        if (device != nil) {
            devName = (device?.name)!
        }

        //  界面加载
        let storyboard  = UIStoryboard(name: "Main", bundle: nil)
        //  蓝牙界面
        let intentBle   : BleTableController    = storyboard.instantiateViewController(withIdentifier: "BleTableController") as! BleTableController;
        //  关于界面
        let intentAbout : AboutController       = storyboard.instantiateViewController(withIdentifier: "AboutController") as! AboutController;
        //  当前读写器
        let reader      = AppDelegate.rfidManager?.getReader();

        //  使用之前清空
        setupManager.clear()

        //  接口
        setupManager.add(XSetupItem(NSLocalizedString("SETUP_PORT", comment:"接口")));
        //  蓝牙接口
        setupManager.add(XSetupItem(XITEM_BLE,title: NSLocalizedString("PORT_BLE", comment:"蓝牙"),text:devName,intent:intentBle));
        //  网络接口
        setupManager.add(XSetupItem(XITEM_WIFI, NSLocalizedString("PORT_TCPIP", comment:"网络"), strNone));
        //  USB接口
        //setupManager.add(XSetupItem(XITEM_USB, NSLocalizedString("PORT_USB", comment:"USB"), strNone));

        //  指令集
        setupManager.add(XSetupItem(NSLocalizedString("SETUP_INSTRUCTION", comment:"指令集")));
        setupManager.add(XSetupItem(XITEM_INSTRUCTION,title: NSLocalizedString("DEVICE_INSTRUCTION", comment:"指令"),pos:(reader!.getType().rawValue),array: arrayInstruct));

        //  设备属性
        setupManager.add(XSetupItem(NSLocalizedString("SETUP_DEVICE", comment:"设备")));
        setupManager.add(XSetupItem(XITEM_AREA,title: NSLocalizedString("DEVICE_AREA", comment:"区域"),pos:reader!.set!.region,array: arrayArea));
        setupManager.add(XSetupItem(XITEM_SKIP,title: NSLocalizedString("DEVICE_AUTO_SKIP", comment:"跳频"),onoff: reader!.set!.auto_skip));
        setupManager.add(XSetupItem(XITEM_TX_POWER,title: NSLocalizedString("DEVICE_TX_POWER", comment:"功率"),pos: reader!.set!.power,min:0,max:33));

        //  显示
        setupManager.add(XSetupItem(NSLocalizedString("SETUP_DISPLAY", comment:"显示")));
        setupManager.add(XSetupItem(XITEM_DISP_INVERT,title: NSLocalizedString("DISPLAY_INVERT", comment:"反向"),onoff:TagItem.useShowInvertText));
        setupManager.add(XSetupItem(XITEM_DISP_TEXT,title: NSLocalizedString("DISPLAY_TEXT", comment:"文本"),onoff: TagItem.useShowEpcUtf8));
        setupManager.add(XSetupItem(XITEM_DISP_MAX,title: NSLocalizedString("DISPLAY_MAX", comment:"上限"),text: (String)(reader!.set!.disp_max),defText: "100"));
        setupManager.add(XSetupItem(XITEM_DISP_DELAY,title: NSLocalizedString("DISPLAY_DELAY", comment:"延时"),text: (String)(reader!.set!.disp_delay),defText: "500"));

        //  操作
        setupManager.add(XSetupItem(NSLocalizedString("SETUP_OPRATE", comment:"操作")));
        setupManager.add(XSetupItem(XITEM_SOUND,title: NSLocalizedString("OPRATE_SOUND", comment:"声音"),onoff: reader!.set!.user_sound));
        //  iOS不支持控制震动
        //setupManager.add(XSetupItem(XITEM_SHAKE,title: NSLocalizedString("OPRATE_SHAKE", comment:"震动"),onoff: reader!.set!.user_shake));
        setupManager.add(XSetupItem(XITEM_SHAKE,title: NSLocalizedString("OPRATE_TIMES", comment:"每秒次数"),pos: reader!.set!.times,array: arrayTimesSec));

        //  其它
        setupManager.add(XSetupItem(NSLocalizedString("SETUP_OTHER", comment:"其他")));
        setupManager.add(XSetupItem(XITEM_ABOUT,title:NSLocalizedString("OTHER_ABOUT", comment:"关于"),intent:intentAbout));

        // 设置管理器 - 关联
        setupManager.setTableView(tableView,self,self);
    }

    /// 返回
    @IBAction func action_back(){
        self.dismiss(animated: true, completion: nil)
    }

    /**
     * 设置响应
     *
     * - parameter msg   : 消息
     * - parameter item  : 设置项目
     * - parameter id    : 项目标号
     * - parameter on    : 逻辑值
     * - parameter pos   : 选择值
     * - parameter text  : 文本值
     * - parameter param : 参数
     */
    func OnSetupEvent(msg:Int,item:XSetupItem,id:Int,on:Bool,pos:Int,text:String?,param:Any?) {
        let rfidMan 	= AppDelegate.rfidManager;
        let reader  	= rfidMan!.getReader();
        let cmd 	= reader?.cmd;
        let set 	= reader?.set;

        if(on){
            NSLog("msg:%d,item:%@,id:%d,on:YES,pos:%d\n",msg,item,id,pos)
        }else{
            NSLog("msg:%d,item:%@,id:%d,on:NO,pos:%d\n",msg,item,id,pos)
        }

	if(reader == nil){
            return;
        }
	
        switch (id) {
        //===============
        //  指令
        //===============
        case XITEM_INSTRUCTION:
            NSLog("指令集 : %d",pos);
            //  切换指令集
            rfidMan!.setType(ReaderType(rawValue: pos)!);
            rfidMan!.setupUpdate(true);
            break;

        //===============
        //  区域
        //===============
        case XITEM_AREA:
            NSLog("区域 : %d", pos);
            set?.region = pos;
            set?.setupUpdate(true);
            AppDelegate.portWrite(cmd!.rfid_set_region(UInt8(arrayCmdArea[pos])));
            rfidMan!.setupUpdate(true);
            break;

        //===============
        //  跳频
        //===============
        case XITEM_SKIP:
            NSLog("跳频 : %d", on);
            //  只针对M100有效
            AppDelegate.portWrite(RfidM100Cmd.cmd_set_auto(on));
            rfidMan!.setupUpdate(true);
            break;

        //===============
        //  功率
        //===============
        case XITEM_TX_POWER:
            NSLog("功率 : %d dBm",pos);
            set?.power = pos;
            set?.setupUpdate(true);
            AppDelegate.portWrite(cmd?.rfid_set_tx_power(UInt8(pos)));
            rfidMan!.setupUpdate(true);
            break;

        //===============
        //  声音
        //===============
        case XITEM_SOUND:
            //  扫标签响
            NSLog("功率 : %d dBm",pos);
            set?.user_sound = on;
            set?.setupUpdate(true);
            break;

        //===============
        //  震动
        //===============
        case XITEM_SHAKE:
            set?.user_shake = on;
            set?.setupUpdate(true);
            break;

        //===============
        //  次数
        //===============
        case XITEM_TIMES:
            set?.times = pos;
            set?.setupUpdate(true);
            break;

        //===============
        //  反向
        //===============
        case XITEM_DISP_INVERT:
            TagItem.useShowInvertText = on;
            TagItem.setupUpdate(true);
            break;

        //===============
        //  文字模式
        //===============
        case XITEM_DISP_TEXT:
            TagItem.useShowEpcUtf8 = on;
            TagItem.setupUpdate(true);
            break;

        //===============
        //  显示上限
        //===============
        case XITEM_DISP_MAX:
            let val = (text! as NSString).intValue;
            set!.disp_max = Int(val);
            set!.setupUpdate(true);
            break;

        //===============
        //  显示延时
        //===============
        case XITEM_DISP_DELAY:
            let val = (text! as NSString).intValue;
            set!.disp_delay = Int(val);
            set!.setupUpdate(true);
            break;

        //===============
        //  调试
        //===============
        case XITEM_DEBUG:
            break;

        default:
            break;
        }
    }
}
