﻿using System.Collections.Generic;

namespace WebPost.Controllers
{
    public class RfidItem
    {
        /// <summary>
        /// 标签
        /// </summary>
        public string epc { get; set; }
        /// <summary>
        /// 天线
        /// </summary>
        public int ant { get; set; }
        /// <summary>
        /// 信号值
        /// </summary>
        public int rssi { get; set; }
        /// <summary>
        /// 次数
        /// </summary>
        public int count { get; set; }

        public override string ToString()
        {
            string buf = "";
            buf += "epc:" + epc + ",";
            buf += "ant:" + ant + ",";
            buf += "rssi:" + rssi + ",";
            buf += "count:" + count + ",";
            return buf;
        }
    };

    public class RfidData
    {
        /// <summary>
        /// 请求号
        /// </summary>
        public string ID { get; set; }
        /// <summary>
        ///  设备名称
        /// </summary>
        public string dev { get; set; }
        /// <summary>
        /// 用户名
        /// </summary>
        public string usr { get; set; }
        /// <summary>
        /// 密码
        /// </summary>
        public string pwd { get; set; }
        /// <summary>
        /// 时间
        /// </summary>
        public string tim { get; set; }

        /// <summary>
        /// 数量列表
        /// </summary>
        public ICollection<RfidItem>list { get; set; }

        public override string ToString()
        {
            string buf = "";
            buf += "ID:" + ID + ",";
            buf += "dev:" + dev + ",";
            buf += "usr:" + usr + ",";
            buf += "pwd:" + pwd + ",";
            buf += "tim:" + tim + ",";
            if (list != null)
            {
                foreach (var e in list)
                {
                    buf += "{" + e + "},\n";
                }
            }
            return buf;
        }
    }
}