﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Razor.TagHelpers;
using Microsoft.Extensions.Logging;
using WebPost.Models;
using Newtonsoft;
using RestSharp;
using Nancy.Json;

namespace WebPost.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        [HttpGet]
        public IActionResult Test()
        {
            return View();
        }

        /// <summary>
        /// 处理post过来的json数据包
        /// </summary>
        /// <param name="postData"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> TestAsync(RfidData postData)
        {
            var postContent = "xxx";

            var req = HttpContext.Request;

            req.EnableBuffering();

            //  数据流
            StreamReader sRead = new StreamReader(req.Body);
            if (sRead != null)
            {
                try
                {
                    sRead.BaseStream.Seek(0, SeekOrigin.Begin);

                    postContent = await sRead.ReadToEndAsync();

                    sRead.Close();

                    Debug.Print("接收内容(1) : (" + postContent + ")");

                }
                catch (Exception e)
                {
                    Debug.Print(e.Message);
                }
            }

            Debug.Print("接收类型 : (" + req.ContentType + ")");
            Debug.Print("接收长度 : (" + req.ContentLength + ")");

            var js = new JavaScriptSerializer();

            //  解析对象
            RfidData obj = js.Deserialize<RfidData>(postContent);

            Debug.Print("接收对象(5) : (" + obj + ")");

            return Json(postContent);

        }

            public static JsonObject Parse(string json)
            {
                var js = new JavaScriptSerializer();
                object obj = js.DeserializeObject(json);
                var v =  new JsonObject();
                //v.Values = obj;
                return v;
            }
        
    }
}
